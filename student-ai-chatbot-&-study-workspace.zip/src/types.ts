export interface Attachment {
  name: string;
  size: number;
  mimeType: string;
  base64Data: string;
}

export interface Message {
  id: string;
  role: 'user' | 'model';
  content: string;
  timestamp: string;
  attachments?: Attachment[];
}

export interface TeacherPersona {
  id: string;
  name: string;
  subject: string;
  description: string;
  iconName: string;
  systemPrompt: string;
  initialMessage: string;
  suggestions: string[];
  isPremiumOnly?: boolean;
}

export interface Flashcard {
  id: string;
  front: string;
  back: string;
  category: string;
  familiarity: 'new' | 'learning' | 'mastered';
}

export interface QuizQuestion {
  question: string;
  options: string[];
  answerIndex: number;
  explanation: string;
}

export interface Quiz {
  id: string;
  topic: string;
  questions: QuizQuestion[];
  score?: number;
  answers?: number[]; // indices of student's selections
}

export interface StudyTask {
  id: string;
  text: string;
  completed: boolean;
  category?: string;
}

export interface ChatSession {
  id: string;
  title: string;
  personaId: string;
  messages: Message[];
  updatedAt: string;
}

