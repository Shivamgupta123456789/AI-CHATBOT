/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from "react";
import AiChat from "./components/AiChat";
import Flashcards from "./components/Flashcards";
import QuizDesk from "./components/QuizDesk";
import ConceptExplainer from "./components/ConceptExplainer";
import StudyPlanTimer from "./components/StudyPlanTimer";
import ProgressDashboard from "./components/ProgressDashboard";
import StudentAuthPortal, { StudentProfile } from "./components/StudentAuthPortal";
import StudentLoginPage from "./components/StudentLoginPage";
import { 
  GraduationCap, MessageSquare, BookOpen, Layers, CheckSquare, 
  Sparkles, TrendingUp, Sun, Moon, User, Crown, ChevronDown 
} from "lucide-react";

export default function App() {
  const [activeTab, setActiveTab] = useState<"chat" | "flash" | "explain" | "quiz" | "timer" | "dashboard">("chat");
  const [isDarkMode, setIsDarkMode] = useState(false); // permanently white/light theme
  const [currentUser, setCurrentUser] = useState<StudentProfile | null>(() => {
    // Load from sessionStorage so fresh tabs always start on the login page
    const saved = sessionStorage.getItem("workspace_current_user");
    try {
      return saved ? JSON.parse(saved) : null;
    } catch (e) {
      return null;
    }
  });
  const [isPremium, setIsPremium] = useState(() => {
    return localStorage.getItem("workspace_premium_unlocked") === "true";
  });
  const [isAuthOpen, setIsAuthOpen] = useState(false);

  const handleLogin = (profile: StudentProfile) => {
    setCurrentUser(profile);
    sessionStorage.setItem("workspace_current_user", JSON.stringify(profile));
    window.dispatchEvent(new Event("student-auth-update"));
  };

  const handleLogout = () => {
    setCurrentUser(null);
    sessionStorage.removeItem("workspace_current_user");
    window.dispatchEvent(new Event("student-auth-update"));
  };

  const handleTogglePremium = () => {
    const nextPremium = !isPremium;
    setIsPremium(nextPremium);
    localStorage.setItem("workspace_premium_unlocked", String(nextPremium));
    window.dispatchEvent(new Event("student-auth-update"));
  };

  // Reactive state synchronization
  useEffect(() => {
    const handleSync = () => {
      const savedUser = sessionStorage.getItem("workspace_current_user");
      try {
        setCurrentUser(savedUser ? JSON.parse(savedUser) : null);
      } catch (e) {
        setCurrentUser(null);
      }
      setIsPremium(localStorage.getItem("workspace_premium_unlocked") === "true");
      setIsDarkMode(false);
    };

    window.addEventListener("student-auth-update", handleSync);
    const handleOpenLogin = () => {
      setIsAuthOpen(true);
    };
    window.addEventListener("open-student-login", handleOpenLogin);

    return () => {
      window.removeEventListener("student-auth-update", handleSync);
      window.removeEventListener("open-student-login", handleOpenLogin);
    };
  }, []);

  const renderActiveWorkspace = () => {
    switch (activeTab) {
      case "flash":
        return <Flashcards />;
      case "explain":
        return <ConceptExplainer />;
      case "quiz":
        return <QuizDesk />;
      case "timer":
        return <StudyPlanTimer />;
      case "dashboard":
        return <ProgressDashboard />;
      default:
        return <AiChat />;
    }
  };

  if (!currentUser) {
    return <StudentLoginPage onLogin={handleLogin} />;
  }

  return (
    <div 
      id="app-viewport" 
      className={`min-h-screen flex flex-col justify-between font-sans antialiased relative selection:bg-zinc-800 selection:text-white ${
        isDarkMode ? "bg-[#050505] text-zinc-200" : "light-theme bg-[#f4f4f7] text-zinc-800"
      }`}
    >
      {/* Real Academic Study Background Photo */}
      <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
        <img 
          src="https://images.unsplash.com/photo-1497633762265-9d179a990aa6?q=85&w=1920&auto=format&fit=crop" 
          alt="Library Study Room Background decoration"
          className={`w-full h-full object-cover transition-all duration-500 ${
            isDarkMode ? "opacity-[0.06] grayscale brightness-50 contrast-125" : "opacity-[0.045] grayscale saturate-50 brightness-110"
          }`}
          referrerPolicy="no-referrer"
        />
      </div>
      {/* Upper Navigation bar and logo banner */}
      <header id="app-header" className="bg-white border-b border-zinc-200 sticky top-0 z-50 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Literal human logo */}
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 bg-indigo-50 rounded-xl flex items-center justify-center text-indigo-600 border border-indigo-100 shadow-sm flex-shrink-0">
                <GraduationCap className="w-5 h-5 animate-pulse" />
              </div>
              <div>
                <h1 className="font-extrabold text-zinc-900 text-sm tracking-tight leading-none flex items-center gap-1.5">
                  DeskMate
                  {isPremium && (
                    <span className="flex items-center gap-0.5 bg-amber-500/10 border border-amber-400/20 text-amber-700 font-extrabold text-[8px] uppercase px-1.5 py-0.5 rounded-full">
                      <Crown className="w-2.5 h-2.5 text-amber-500 fill-amber-450/5" />
                      Premium
                    </span>
                  )}
                </h1>
                <p className="text-[10px] text-zinc-500 font-medium tracking-wide mt-0.5 font-sans">
                  Your Student AI Chatbot & Study Workspace
                </p>
              </div>
            </div>

            {/* Header Widgets: Theme toggler, Premium status, and Profile control */}
            <div className="flex items-center gap-2.5">
              {/* Day Mode / White Theme Indicator */}
              <div
                id="theme-toggler"
                className="px-3 py-1.5 bg-zinc-50 border border-zinc-200 rounded-xl text-amber-600 text-[10px] font-extrabold flex items-center gap-1.5 tracking-wider uppercase select-none"
                title="Workspace locked in White Theme"
              >
                <Sun className="w-3.5 h-3.5 text-amber-500 animate-spin-slow" />
                <span className="hidden sm:inline">White Theme Active</span>
              </div>

              {/* Account Status / Profile Pill Badge */}
              {currentUser ? (
                <button
                  id="header-profile-badge"
                  onClick={() => setIsAuthOpen(true)}
                  className="bg-zinc-50 border border-zinc-200 hover:border-zinc-300 py-1.5 px-3 rounded-xl flex items-center gap-2 transition cursor-pointer max-w-[200px]"
                >
                  <div className={`w-6 h-6 rounded-full ${currentUser.color || "bg-indigo-500"} flex items-center justify-center text-[10px] font-extrabold text-white shadow-inner flex-shrink-0`}>
                    {currentUser.avatarSeed}
                  </div>
                  <div className="text-left hidden md:block max-w-[125px]">
                    <h4 className="text-[11px] font-extrabold text-zinc-800 truncate leading-none">
                      {currentUser.name}
                    </h4>
                    <p className="text-[9px] text-indigo-600 font-semibold truncate mt-1">
                      {isPremium ? "Premium Scholar" : "Basic Scholar"}
                    </p>
                  </div>
                  <ChevronDown className="w-3 h-3 text-zinc-400" />
                </button>
              ) : (
                <button
                  id="header-login-trigger"
                  onClick={() => setIsAuthOpen(true)}
                  className="bg-indigo-600 border border-indigo-500 hover:bg-indigo-500 text-white font-bold text-xs py-2 px-3.5 rounded-xl transition cursor-pointer flex items-center gap-1.5 shadow-md flex-shrink-0"
                >
                  <User className="w-3.5 h-3.5 text-indigo-200" />
                  <span className="hidden sm:inline">Student Login</span>
                </button>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Main Dynamic Stage area */}
      <main id="app-stage" className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 flex flex-col gap-6 relative z-10">
        
        {/* Workspace Hub Navigation bar */}
        <section id="workspace-navigator" className="bg-white border border-zinc-200 rounded-xl p-2 shadow-sm">
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-1 select-none">
            <button
              id="tab-chat"
              onClick={() => setActiveTab("chat")}
              className={`py-3 rounded-lg text-xs font-bold tracking-tight transition flex items-center justify-center gap-2 cursor-pointer ${
                activeTab === "chat"
                  ? "bg-indigo-600 border border-indigo-500 text-white shadow-sm"
                  : "bg-white text-zinc-650 hover:text-zinc-900 hover:bg-zinc-50 border border-transparent"
              }`}
            >
              <MessageSquare className="w-3.5 h-3.5" />
              AI Mentor Chat
            </button>

            <button
              id="tab-explain"
              onClick={() => setActiveTab("explain")}
              className={`py-3 rounded-lg text-xs font-bold tracking-tight transition flex items-center justify-center gap-2 cursor-pointer ${
                activeTab === "explain"
                  ? "bg-indigo-600 border border-indigo-500 text-white shadow-sm"
                  : "bg-white text-zinc-650 hover:text-zinc-900 hover:bg-zinc-50 border border-transparent"
              }`}
            >
              <BookOpen className="w-3.5 h-3.5" />
              Summarize & Explain
            </button>

            <button
              id="tab-quiz"
              onClick={() => setActiveTab("quiz")}
              className={`py-3 rounded-lg text-xs font-bold tracking-tight transition flex items-center justify-center gap-2 cursor-pointer ${
                activeTab === "quiz"
                  ? "bg-indigo-600 border border-indigo-500 text-white shadow-sm"
                  : "bg-white text-zinc-650 hover:text-zinc-900 hover:bg-zinc-50 border border-transparent"
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              Adaptive Quiz
            </button>

            <button
              id="tab-flash"
              onClick={() => setActiveTab("flash")}
              className={`py-3 rounded-lg text-xs font-bold tracking-tight transition flex items-center justify-center gap-2 cursor-pointer ${
                activeTab === "flash"
                  ? "bg-indigo-600 border border-indigo-500 text-white shadow-sm"
                  : "bg-white text-zinc-650 hover:text-zinc-900 hover:bg-zinc-50 border border-transparent"
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              Flashcard Builder
            </button>

            <button
              id="tab-timer"
              onClick={() => setActiveTab("timer")}
              className={`py-3 rounded-lg text-xs font-bold tracking-tight transition flex items-center justify-center gap-2 cursor-pointer ${
                activeTab === "timer"
                  ? "bg-indigo-600 border border-indigo-500 text-white shadow-sm"
                  : "bg-white text-zinc-650 hover:text-zinc-900 hover:bg-zinc-50 border border-transparent"
              }`}
            >
              <CheckSquare className="w-3.5 h-3.5" />
              Plan & Focus Timer
            </button>

            <button
              id="tab-dashboard"
              onClick={() => setActiveTab("dashboard")}
              className={`py-3 rounded-lg text-xs font-bold tracking-tight transition flex items-center justify-center gap-2 cursor-pointer ${
                activeTab === "dashboard"
                  ? "bg-indigo-600 border border-indigo-500 text-white shadow-sm"
                  : "bg-white text-zinc-650 hover:text-zinc-900 hover:bg-zinc-50 border border-transparent"
              }`}
            >
              <TrendingUp className="w-3.5 h-3.5" />
              Progress Dashboard
            </button>
          </div>
        </section>

        {/* Workspace Active screen container */}
        <section id="workspace-canvas" className="flex-1">
          {renderActiveWorkspace()}
        </section>
      </main>

      {/* Workspace Footer details */}
      <footer id="app-footer" className="bg-white border-t border-zinc-200 py-5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-left">
          <p className="text-[10px] text-zinc-500 font-normal">
            &copy; 2026 Student AI Chatbot & Study Workspace. Built for active recalling and B.Tech branch learning.
          </p>
          <div className="flex items-center gap-4 text-[10px] text-zinc-500 font-medium">
            <span>Powered by Gemini 3.5 Flash</span>
            <span className="hidden sm:inline text-zinc-300">|</span>
            <span>Secure Full-Stack Proxy Architecture</span>
          </div>
        </div>
      </footer>

      {/* Student Authorization Portal Dialog overlay */}
      <StudentAuthPortal 
        isOpen={isAuthOpen} 
        onClose={() => setIsAuthOpen(false)} 
        currentUser={currentUser}
        onLogin={handleLogin}
        onLogout={handleLogout}
        isPremium={isPremium}
        onTogglePremium={handleTogglePremium}
      />
    </div>
  );
}
