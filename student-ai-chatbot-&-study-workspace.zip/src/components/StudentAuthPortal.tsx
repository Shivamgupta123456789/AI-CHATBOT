import { useState, useId, FormEvent } from "react";
import { 
  User, GraduationCap, LogOut, Crown, Zap, X, ShieldCheck, 
  Check, Sparkles, Mail, BookOpen 
} from "lucide-react";

export interface StudentProfile {
  name: string;
  email: string;
  major: string;
  avatarSeed: string;
  color: string;
}

const PRESET_STUDENTS: StudentProfile[] = [
  {
    name: "Rohan Sharma",
    email: "rohan.cse@btech.edu",
    major: "B.Tech Computer Science & Engineering (CSE)",
    avatarSeed: "RS",
    color: "bg-indigo-650"
  },
  {
    name: "Priya Patel",
    email: "priya.ece@btech.edu",
    major: "B.Tech Electronics & Communication Engineering (ECE)",
    avatarSeed: "PP",
    color: "bg-emerald-600"
  },
  {
    name: "Vikram Singh",
    email: "vikram.me@btech.edu",
    major: "B.Tech Mechanical Engineering (ME)",
    avatarSeed: "VS",
    color: "bg-amber-600"
  },
  {
    name: "Ananya Iyer",
    email: "ananya.bt@btech.edu",
    major: "B.Tech Biotechnology Engineering (BT)",
    avatarSeed: "AI",
    color: "bg-purple-600"
  },
  {
    name: "Kabir Mehta",
    email: "kabir.ce@btech.edu",
    major: "B.Tech Civil Engineering (CE)",
    avatarSeed: "KM",
    color: "bg-rose-600"
  }
];

interface StudentAuthPortalProps {
  currentUser: StudentProfile | null;
  onLogin: (profile: StudentProfile) => void;
  onLogout: () => void;
  isPremium: boolean;
  onTogglePremium: () => void;
  isOpen: boolean;
  onClose: () => void;
}

export default function StudentAuthPortal({
  currentUser,
  onLogin,
  onLogout,
  isPremium,
  onTogglePremium,
  isOpen,
  onClose
}: StudentAuthPortalProps) {
  const [customName, setCustomName] = useState("");
  const [customEmail, setCustomEmail] = useState("");
  const [customMajor, setCustomMajor] = useState("B.Tech Computer Science & Engineering (CSE)");
  const [activePreset, setActivePreset] = useState<number | null>(null);

  const nameInputId = useId();
  const mailInputId = useId();
  const majorInputId = useId();

  if (!isOpen) return null;

  const handleCustomLogin = (e: FormEvent) => {
    e.preventDefault();
    if (!customName.trim() || !customEmail.trim()) return;

    const initialLetter = customName.trim().substring(0, 2).toUpperCase();
    onLogin({
      name: customName.trim(),
      email: customEmail.trim(),
      major: customMajor,
      avatarSeed: initialLetter.length > 1 ? initialLetter : initialLetter + "S",
      color: "bg-rose-500"
    });
    
    // reset form
    setCustomName("");
    setCustomEmail("");
    onClose();
  };

  const handleSelectPreset = (idx: number) => {
    setActivePreset(idx);
    onLogin(PRESET_STUDENTS[idx]);
    setTimeout(() => {
      onClose();
    }, 400); // smooth closure
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Dark Overlay backdrop */}
      <div 
        id="auth-overlay-backdrop"
        onClick={onClose}
        className="absolute inset-0 bg-black/80 backdrop-blur-sm transition-opacity"
      />

      {/* Main Authentication Card container */}
      <div 
        id="student-auth-dialog"
        className="relative bg-[#111111] border border-zinc-850 rounded-2xl w-full max-w-md shadow-2xl overflow-hidden text-zinc-200 p-6 animate-fade-in z-10"
      >
        {/* Header toolbar */}
        <div className="flex items-center justify-between pb-4 border-b border-zinc-900 mb-5">
          <div className="flex items-center gap-2">
            <GraduationCap className="h-5 w-5 text-indigo-400" />
            <h3 className="font-bold text-zinc-100 text-sm tracking-tight">Student Access Portal</h3>
          </div>
          <button 
            onClick={onClose}
            className="text-zinc-500 hover:text-zinc-200 p-1.5 hover:bg-zinc-900 rounded-lg transition"
            title="Close authentication center"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {currentUser ? (
          /* Profile Details Screen when Logged In */
          <div className="flex flex-col gap-5">
            <div className="bg-zinc-950/40 border border-zinc-900 p-4 rounded-xl flex items-center gap-4">
              <div className={`w-12 h-12 rounded-full ${currentUser.color} flex items-center justify-center text-white font-extrabold text-sm shadow-md`}>
                {currentUser.avatarSeed}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5">
                  <h4 className="font-extrabold text-white text-sm truncate">{currentUser.name}</h4>
                  {isPremium ? (
                    <span className="flex items-center gap-0.5 bg-amber-500/10 border border-amber-400/20 text-amber-400 font-extrabold text-[8px] uppercase px-1.5 py-0.5 rounded-full">
                      <Crown className="w-2.5 h-2.5 fill-amber-400 text-current" />
                      Premium
                    </span>
                  ) : (
                    <span className="bg-zinc-800 text-zinc-400 font-bold text-[8px] uppercase px-1.5 py-0.5 rounded-full">
                      Basic Scholar
                    </span>
                  )}
                </div>
                <p className="text-[11px] text-zinc-400 truncate mt-0.5">{currentUser.email}</p>
                <p className="text-[10px] text-zinc-550 font-medium truncate mt-1 flex items-center gap-1">
                  <BookOpen className="w-3 h-3 text-indigo-400" />
                  {currentUser.major}
                </p>
              </div>
            </div>

            {/* Premium feature control block */}
            <div className="bg-gradient-to-br from-indigo-950/20 to-zinc-950 border border-zinc-900 p-4.5 rounded-xl flex flex-col gap-3">
              <div className="flex justify-between items-start">
                <div>
                  <h4 className="text-xs font-bold text-zinc-100 flex items-center gap-1">
                    <Crown className="w-4 h-4 text-amber-500" />
                    Premium Upgrade Status
                  </h4>
                  <p className="text-[10px] text-zinc-450 mt-1">
                    Unlock extra chat limits, advanced AI tutoring reasoning modes, and unrestricted deep concept-by-concept analysis guides.
                  </p>
                </div>
                
                <button
                  onClick={onTogglePremium}
                  id="toggle-premium-plan-btn"
                  className={`px-3 py-1.5 rounded-lg text-[10px] font-bold tracking-tight transition cursor-pointer flex items-center gap-1 ${
                    isPremium 
                      ? "bg-amber-500 hover:bg-amber-600 text-black shadow-md shadow-amber-500/10" 
                      : "bg-zinc-100 hover:bg-white text-black"
                  }`}
                >
                  {isPremium ? (
                    <>
                      <ShieldCheck className="w-3 h-3 text-current" />
                      Activated!
                    </>
                  ) : (
                    <>
                      <Zap className="w-3 h-3 text-current fill-current" />
                      Go Premium (Free)
                    </>
                  )}
                </button>
              </div>

              {/* Premium Perks visual indicators */}
              <div className="grid grid-cols-2 gap-2 mt-1 pt-2 border-t border-zinc-900/60 text-[10px] text-zinc-400">
                <div className="flex items-center gap-1.5">
                  <Check className="w-3 h-3 text-indigo-400" />
                  <span>Unlimited Chat Cycles</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Check className="w-3 h-3 text-indigo-400" />
                  <span>Advanced Reasoning AI</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Check className="w-3 h-3 text-indigo-400" />
                  <span>Interactive Real-time PDF Guides</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Check className="w-3 h-3 text-indigo-400" />
                  <span>Unlimited Flashcards & Quizzes</span>
                </div>
              </div>
            </div>

            {/* Logout button */}
            <button
              onClick={() => {
                onLogout();
                onClose();
              }}
              id="student-logout-action"
              className="bg-zinc-950 hover:bg-red-950/30 hover:text-red-400 text-zinc-400 border border-zinc-900 py-2.5 px-4 rounded-xl text-xs font-semibold tracking-tight transition duration-150 flex items-center justify-center gap-2 cursor-pointer"
            >
              <LogOut className="w-4 h-4" />
              Sign Out Student Profile
            </button>
          </div>
        ) : (
          /* Authentication / Log In Choices Dialog */
          <div className="flex flex-col gap-5">
            
            {/* Presets List */}
            <div className="flex flex-col gap-2.5">
              <span className="text-[9px] font-bold text-zinc-500 uppercase tracking-widest block mb-1">
                Select Pre-configured Student Account:
              </span>
              
              <div className="flex flex-col gap-2">
                {PRESET_STUDENTS.map((preset, idx) => (
                  <button
                    key={preset.name}
                    onClick={() => handleSelectPreset(idx)}
                    className="w-full text-left bg-zinc-950 border border-zinc-900 hover:border-zinc-700 p-3 rounded-xl transition flex items-center gap-3 cursor-pointer group"
                  >
                    <div className={`w-9 h-9 rounded-full ${preset.color} flex items-center justify-center text-white font-bold text-xs shadow-sm`}>
                      {preset.avatarSeed}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <h4 className="font-bold text-zinc-100 text-xs truncate group-hover:text-white">{preset.name}</h4>
                        <span className="text-[8px] text-zinc-550 group-hover:text-indigo-400 font-semibold uppercase">Log in &rarr;</span>
                      </div>
                      <p className="text-[10px] text-zinc-455 truncate leading-tight">{preset.email}</p>
                      <p className="text-[10px] text-zinc-500 truncate mt-0.5">{preset.major}</p>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Divider */}
            <div className="flex items-center gap-3 my-1">
              <div className="h-px bg-zinc-900 flex-1" />
              <span className="text-[9px] text-zinc-600 font-bold uppercase tracking-widest font-mono">OR</span>
              <div className="h-px bg-zinc-900 flex-1" />
            </div>

            {/* Custom Student profile builder form */}
            <form onSubmit={handleCustomLogin} className="flex flex-col gap-3">
              <span className="text-[9px] font-bold text-zinc-500 uppercase tracking-widest block">
                Create Custom Student Scholar:
              </span>

              <div className="flex flex-col gap-1">
                <label htmlFor={nameInputId} className="text-[9px] font-bold text-zinc-450 uppercase tracking-wider">Full Name</label>
                <div className="relative">
                  <User className="w-3.5 h-3.5 text-zinc-550 absolute left-3 top-3" />
                  <input
                    id={nameInputId}
                    type="text"
                    required
                    placeholder="e.g. Liam Sterling"
                    value={customName}
                    onChange={e => setCustomName(e.target.value)}
                    className="w-full bg-zinc-900/40 border border-zinc-850 rounded-xl pl-9 pr-3 py-2 text-xs text-zinc-200 focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <div className="flex flex-col gap-1">
                <label htmlFor={mailInputId} className="text-[9px] font-bold text-zinc-450 uppercase tracking-wider">Academic Email</label>
                <div className="relative">
                  <Mail className="w-3.5 h-3.5 text-zinc-550 absolute left-3 top-3" />
                  <input
                    id={mailInputId}
                    type="email"
                    required
                    placeholder="e.g. liam@academics.edu"
                    value={customEmail}
                    onChange={e => setCustomEmail(e.target.value)}
                    className="w-full bg-zinc-900/40 border border-zinc-850 rounded-xl pl-9 pr-3 py-2 text-xs text-zinc-200 focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <div className="flex flex-col gap-0.5">
                <label htmlFor={majorInputId} className="text-[9px] font-bold text-zinc-450 uppercase tracking-wider">Major / Domain Group</label>
                <select
                  id={majorInputId}
                  value={customMajor}
                  onChange={e => setCustomMajor(e.target.value)}
                  className="w-full bg-zinc-900 border border-zinc-850 rounded-xl px-3 py-2 text-xs text-zinc-200 focus:outline-none focus:border-indigo-500 select-dropdown mt-0.5"
                >
                  <option value="B.Tech Computer Science & Engineering (CSE)">B.Tech Computer Science & Engineering (CSE)</option>
                  <option value="B.Tech Electronics & Communication Engineering (ECE)">B.Tech Electronics & Communication Engineering (ECE)</option>
                  <option value="B.Tech Mechanical Engineering (ME)">B.Tech Mechanical Engineering (ME)</option>
                  <option value="B.Tech Biotechnology Engineering (BT)">B.Tech Biotechnology Engineering (BT)</option>
                  <option value="B.Tech Civil Engineering (CE)">B.Tech Civil Engineering (CE)</option>
                  <option value="B.Tech Information Technology (IT)">B.Tech Information Technology (IT)</option>
                  <option value="B.Tech Electrical & Electronics Engineering (EEE)">B.Tech Electrical & Electronics Engineering (EEE)</option>
                  <option value="B.Tech Chemical Engineering (CH)">B.Tech Chemical Engineering (CH)</option>
                  <option value="B.Tech Artificial Intelligence & Data Science (AI & DS)">B.Tech Artificial Intelligence & Data Science (AI & DS)</option>
                </select>
              </div>

              {/* Submit trigger */}
              <button
                type="submit"
                disabled={!customName.trim() || !customEmail.trim()}
                className="bg-indigo-650 hover:bg-indigo-600 text-white font-semibold text-xs py-2.5 rounded-xl transition mt-2 disabled:opacity-40 cursor-pointer flex items-center justify-center gap-1.5"
              >
                <Sparkles className="w-3.5 h-3.5 text-indigo-300" />
                Initialize Custom Scholar Profile
              </button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
}
