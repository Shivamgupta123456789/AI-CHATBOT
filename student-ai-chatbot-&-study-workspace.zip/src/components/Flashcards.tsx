import { useState, useEffect, FormEvent } from "react";
import { Flashcard } from "../types";
import { Sparkles, Layers, Plus, ChevronLeft, ChevronRight, Eye } from "lucide-react";

export default function Flashcards() {
  const [cards, setCards] = useState<Flashcard[]>(() => {
    const saved = localStorage.getItem("workspace_flashcards");
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (parsed?.length > 0) return parsed;
      } catch (e) {}
    }
    // Default fallback starter cards
    return [
      { id: "1", front: "What is active recall?", back: "A learning principle that tests memory retrieval instead of passive reading. Forces the brain to retrieve info.", category: "Learning Science", familiarity: "new" },
      { id: "2", front: "Explain the Spacing Effect (Distributed Practice)", back: "The practice of spacing out learning periods over time to prevent memory decay (forgetting curve).", category: "Learning Science", familiarity: "learning" },
      { id: "3", front: "What is the Feynman Technique?", back: "A method to simplify learning by explaining any concept out loud as if you are teaching it to a child.", category: "Study Methods", familiarity: "mastered" }
    ];
  });

  const [aiConcept, setAiConcept] = useState("");
  const [customNotes, setCustomNotes] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [err, setErr] = useState("");
  
  // Custom manual card state
  const [showAddManual, setShowAddManual] = useState(false);
  const [manualFront, setManualFront] = useState("");
  const [manualBack, setManualBack] = useState("");
  const [manualCategory, setManualCategory] = useState("");

  // Flipping active card tracking
  const [activeIndex, setActiveIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  
  // Filter state
  const [filter, setFilter] = useState<'all' | 'new' | 'learning' | 'mastered'>('all');

  useEffect(() => {
    localStorage.setItem("workspace_flashcards", JSON.stringify(cards));
  }, [cards]);

  const handleGenerateAiCards = async () => {
    if (!aiConcept.trim() && !customNotes.trim()) {
      setErr("Please type either a subject topic or paste textbook notes.");
      return;
    }
    setErr("");
    setIsLoading(true);

    try {
      const res = await fetch("/api/generate-flashcards", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ topic: aiConcept, customNotes })
      });

      if (!res.ok) {
        throw new Error("Unable to trigger flashcard compilation.");
      }

      const data = await res.json();
      if (!data.flashcards || data.flashcards.length === 0) {
        throw new Error("Found no generated flashcards. Try another topic query.");
      }

      const incoming: Flashcard[] = data.flashcards.map((fc: any) => ({
        id: Math.random().toString(),
        front: fc.front,
        back: fc.back,
        category: fc.category || "General Studies",
        familiarity: "new" as const
      }));

      setCards(prev => [...incoming, ...prev]);
      setActiveIndex(0);
      setIsFlipped(false);
      setAiConcept("");
      setCustomNotes("");
    } catch (error: any) {
      setErr(error.message || "Something went wrong.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddManualCard = (e: FormEvent) => {
    e.preventDefault();
    if (!manualFront.trim() || !manualBack.trim()) return;

    const newCard: Flashcard = {
      id: Math.random().toString(),
      front: manualFront,
      back: manualBack,
      category: manualCategory.trim() || "Manual Card",
      familiarity: "new"
    };

    setCards(prev => [newCard, ...prev]);
    setActiveIndex(0);
    setIsFlipped(false);
    setManualFront("");
    setManualBack("");
    setManualCategory("");
    setShowAddManual(false);
  };

  const updateCardFamiliarity = (id: string, state: 'new' | 'learning' | 'mastered') => {
    setCards(prev => prev.map(c => c.id === id ? { ...c, familiarity: state } : c));
  };

  const handleDeleteCard = (id: string) => {
    if (confirm("Delete this card permanently?")) {
      const idx = cards.findIndex(c => c.id === id);
      setCards(prev => prev.filter(c => c.id !== id));
      setIsFlipped(false);
      if (idx >= cards.length - 1) {
        setActiveIndex(Math.max(0, cards.length - 2));
      }
    }
  };

  const filteredCards = cards.filter(c => filter === 'all' ? true : c.familiarity === filter);

  const rotateToPrev = () => {
    setIsFlipped(false);
    setTimeout(() => {
      setActiveIndex(prev => (prev === 0 ? filteredCards.length - 1 : prev - 1));
    }, 150);
  };

  const rotateToNext = () => {
    setIsFlipped(false);
    setTimeout(() => {
      setActiveIndex(prev => (prev === filteredCards.length - 1 ? 0 : prev + 1));
    }, 150);
  };

  const activeCard = filteredCards[activeIndex];

  return (
    <div id="flashcards-root" className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Settings / Generator Panel */}
      <div id="flashcards-sidebar" className="bg-white border border-zinc-200 rounded-xl p-5 flex flex-col gap-4 shadow-sm">
        <div>
          <h3 id="flashcards-sidebar-title" className="font-semibold text-zinc-800 text-sm tracking-tight flex items-center gap-1.5 pb-2 border-b border-zinc-200">
            <Sparkles className="h-4 w-4 text-indigo-650" />
            AI Flashcard Builder
          </h3>
          <p className="text-[11px] text-zinc-500 mt-1">
            Let the AI evaluate your study topic or uploaded notes and compile active-recall memory decks instantly.
          </p>
        </div>

        {/* AI Prompt Input */}
        <div className="flex flex-col gap-3 mt-1">
          <div className="flex flex-col gap-1">
            <label className="text-[10px] font-bold tracking-wider text-zinc-400 uppercase">SUBJECT OR TOPIC</label>
            <input
              type="text"
              placeholder="e.g. Krebs Cycle, US President of 1860"
              value={aiConcept}
              onChange={e => setAiConcept(e.target.value)}
              disabled={isLoading}
              className="bg-white border border-zinc-200 focus:outline-none focus:border-indigo-500 rounded-lg px-3 py-2 text-xs text-zinc-800 placeholder-zinc-400 font-normal shadow-sm"
            />
          </div>

          <div className="flex flex-col gap-1">
            <label className="text-[10px] font-bold tracking-wider text-zinc-400 uppercase">OR PASTE TEXTBOOK NOTES</label>
            <textarea
              placeholder="Paste raw textbook text, lectures, or paragraphs here and let AI forge a tailored trivia review sheet..."
              rows={4}
              value={customNotes}
              onChange={e => setCustomNotes(e.target.value)}
              disabled={isLoading}
              className="bg-white border border-zinc-200 focus:outline-none focus:border-indigo-500 rounded-lg px-3 py-2 text-xs text-zinc-800 placeholder-zinc-400 font-normal resize-none shadow-sm"
            />
          </div>

          <button
            id="compile-cards-btn"
            onClick={handleGenerateAiCards}
            disabled={isLoading || (!aiConcept.trim() && !customNotes.trim())}
            className="w-full bg-indigo-600 hover:bg-indigo-500 text-white transition rounded-lg py-2 text-xs font-bold flex items-center justify-center gap-1.5 disabled:opacity-40 cursor-pointer"
          >
            {isLoading ? "Generating deck..." : "Build Study Cards"}
          </button>
        </div>

        {err && (
          <div className="p-2.5 rounded border border-red-200 bg-red-50 text-[10px] text-red-650 font-semibold">
            {err}
          </div>
        )}

        <hr className="border-zinc-200 my-1" />

        {/* Manual card toggler */}
        <div>
          <button
            id="toggle-manual-form-btn"
            onClick={() => setShowAddManual(p => !p)}
            className="text-xs text-indigo-600 font-bold hover:text-indigo-500 tracking-tight flex items-center gap-1 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            {showAddManual ? "Hide Manual Form" : "Create Card Manually"}
          </button>

          {showAddManual && (
            <form onSubmit={handleAddManualCard} className="mt-3 bg-zinc-50 border border-zinc-200 p-3 rounded-lg flex flex-col gap-2.5 shadow-sm">
              <div className="flex flex-col gap-0.5">
                <label className="text-[9px] font-semibold text-zinc-500">FRONT (Question or Term)</label>
                <input
                  type="text"
                  required
                  value={manualFront}
                  onChange={e => setManualFront(e.target.value)}
                  className="bg-white border border-zinc-205 focus:border-indigo-500 focus:outline-none rounded px-2.5 py-1.5 text-xs text-zinc-800"
                  placeholder="e.g. Mitochondria"
                />
              </div>
              <div className="flex flex-col gap-0.5">
                <label className="text-[9px] font-semibold text-zinc-500">BACK (Answer or Explanation)</label>
                <textarea
                  required
                  rows={2}
                  value={manualBack}
                  onChange={e => setManualBack(e.target.value)}
                  className="bg-white border border-zinc-205 focus:border-indigo-500 focus:outline-none rounded px-2.5 py-1.5 text-xs text-zinc-800 resize-none"
                  placeholder="The powerhouse of the cell."
                />
              </div>
              <div className="flex flex-col gap-0.5">
                <label className="text-[9px] font-semibold text-zinc-500">CATEGORY</label>
                <input
                  type="text"
                  value={manualCategory}
                  onChange={e => setManualCategory(e.target.value)}
                  className="bg-white border border-zinc-205 focus:border-indigo-500 focus:outline-none rounded px-2.5 py-1.5 text-xs text-zinc-800"
                  placeholder="e.g. Biology"
                />
              </div>
              <button
                type="submit"
                className="bg-indigo-650 text-white rounded py-1.5 text-[11px] font-bold hover:bg-indigo-600 transition cursor-pointer"
              >
                Insert Card
              </button>
            </form>
          )}
        </div>
      </div>

      {/* Main Study Desk Canvas */}
      <div id="flashcards-desk" className="lg:col-span-2 flex flex-col gap-4">
        {/* Filtering Tabs & Header */}
        <div className="bg-white border border-zinc-200 rounded-xl p-3 flex items-center justify-between shadow-sm font-sans">
          <div className="flex items-center gap-1 bg-zinc-100 p-1 rounded-lg border border-zinc-200 select-none">
            {(['all', 'new', 'learning', 'mastered'] as const).map(f => (
              <button
                key={f}
                id={`filter-${f}`}
                onClick={() => {
                  setFilter(f);
                  setActiveIndex(0);
                  setIsFlipped(false);
                }}
                className={`px-3 py-1 rounded-md text-[10px] font-semibold transition cursor-pointer ${
                  filter === f 
                    ? "bg-white text-zinc-800 shadow-sm" 
                    : "text-zinc-500 hover:text-zinc-800"
                }`}
              >
                {f.toUpperCase()}
              </button>
            ))}
          </div>
          <span className="text-[11px] text-zinc-500 font-mono font-medium">
            {filteredCards.length} Active card{filteredCards.length !== 1 && 's'}
          </span>
        </div>

        {/* Card Stage with elegant CSS Flip animation */}
        {filteredCards.length > 0 && activeCard ? (
          <div className="flex flex-col gap-4">
            {/* Perspective flip container */}
            <div 
              id="3d-flip-stage"
              className="group h-76 [perspective:1000px] cursor-pointer"
              onClick={() => setIsFlipped(f => !f)}
            >
              <div 
                id="3d-card-inner"
                className={`relative w-full h-full duration-500 [transform-style:preserve-3d] transition-transform ${
                  isFlipped ? "[transform:rotateY(180deg)]" : ""
                }`}
              >
                {/* Front Side */}
                <div id="card-side-front" className="absolute inset-0 bg-white border border-zinc-200 rounded-2xl p-6 flex flex-col justify-between shadow-sm [backface-visibility:hidden]">
                  <div className="flex items-center justify-between">
                    <span className="bg-indigo-55 border border-indigo-100 text-indigo-700 text-[9px] font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wide">
                      {activeCard.category}
                    </span>
                    <span className="text-[10px] font-mono text-zinc-400">Question</span>
                  </div>
                  <div className="text-center py-6 px-4">
                    <p className="text-zinc-800 text-base font-bold leading-snug tracking-tight">
                      {activeCard.front}
                    </p>
                  </div>
                  <div className="text-center">
                    <span className="text-[10px] text-zinc-455 font-semibold flex items-center justify-center gap-1 group-hover:text-indigo-600 transition">
                      <Eye className="w-3.5 h-3.5" /> Tap Card to Flip Answer
                    </span>
                  </div>
                </div>

                {/* Back Side */}
                <div id="card-side-back" className="absolute inset-0 bg-indigo-600 border border-indigo-500 rounded-2xl p-6 flex flex-col justify-between shadow-sm [backface-visibility:hidden] [transform:rotateY(180deg)] text-white">
                  <div className="flex items-center justify-between">
                    <span className="bg-indigo-750 border border-indigo-700 text-indigo-100 text-[9px] font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wide">
                      {activeCard.category}
                    </span>
                    <span className="text-[10px] font-mono text-indigo-200">Detailed explanation</span>
                  </div>
                  <div className="text-center py-6 px-4">
                    <p className="text-white leading-relaxed text-xs font-semibold">
                      {activeCard.back}
                    </p>
                  </div>
                  <div className="text-center font-mono text-[9px] text-indigo-200/90">
                    Perfect recall relies on testing logic!
                  </div>
                </div>
              </div>
            </div>

            {/* Pagination Controls */}
            <div id="card-pagination" className="flex items-center justify-between bg-white border border-zinc-200 p-3.5 rounded-xl shadow-sm">
              <button
                id="prev-card-btn"
                onClick={rotateToPrev}
                className="p-1.5 rounded-lg border border-zinc-200 hover:border-zinc-400 hover:bg-zinc-50 transition cursor-pointer"
              >
                <ChevronLeft className="w-4 h-4 text-zinc-650" />
              </button>

              <span className="text-[11px] text-zinc-600 font-semibold font-mono">
                Card {activeIndex + 1} of {filteredCards.length}
              </span>

              <button
                id="next-card-btn"
                onClick={rotateToNext}
                className="p-1.5 rounded-lg border border-zinc-200 hover:border-zinc-400 hover:bg-zinc-50 transition cursor-pointer"
              >
                <ChevronRight className="w-4 h-4 text-zinc-650" />
              </button>
            </div>

            {/* Mastery Evaluation Bar */}
            <div id="mastery-grading-bar" className="bg-white border border-zinc-200 rounded-2xl p-4 shadow-sm">
              <span className="text-[9px] font-bold tracking-wider text-zinc-400 uppercase block mb-3 text-center">HOW WELL DO YOU RECALL THIS CONCEPT?</span>
              <div className="grid grid-cols-3 gap-3">
                <button
                  id="re-evaluate-new"
                  onClick={() => updateCardFamiliarity(activeCard.id, 'new')}
                  className={`py-2 rounded-xl text-xs border tracking-tight font-semibold cursor-pointer transition-all ${
                    activeCard.familiarity === 'new' 
                      ? "bg-rose-50 border-rose-300 text-rose-700 hover:bg-rose-100" 
                      : "bg-white border-zinc-200 hover:border-rose-450 text-zinc-500 hover:bg-rose-50/20"
                  }`}
                >
                  Still Confused
                </button>
                <button
                  id="re-evaluate-learning"
                  onClick={() => updateCardFamiliarity(activeCard.id, 'learning')}
                  className={`py-2 rounded-xl text-xs border tracking-tight font-semibold cursor-pointer transition-all ${
                    activeCard.familiarity === 'learning' 
                      ? "bg-amber-50 border-amber-300 text-amber-800 hover:bg-amber-100" 
                      : "bg-white border-zinc-200 hover:border-amber-450 text-zinc-500 hover:bg-amber-50/20"
                  }`}
                >
                  Rough Recall
                </button>
                <button
                  id="re-evaluate-mastered"
                  onClick={() => updateCardFamiliarity(activeCard.id, 'mastered')}
                  className={`py-2 rounded-xl text-xs border tracking-tight font-semibold cursor-pointer transition-all ${
                    activeCard.familiarity === 'mastered' 
                      ? "bg-emerald-50 border-emerald-300 text-emerald-750 hover:bg-emerald-100" 
                      : "bg-white border-zinc-200 hover:border-emerald-450 text-zinc-500 hover:bg-emerald-50/25"
                  }`}
                >
                  Familiarized!
                </button>
              </div>

              <div className="flex items-center justify-between mt-3 px-1 text-[11px]">
                <span className="text-zinc-500 font-medium">Recall rating lets you customize study focuses.</span>
                <button 
                  id={`del-card-${activeCard.id}`}
                  onClick={() => handleDeleteCard(activeCard.id)}
                  className="text-red-500 hover:text-red-600 font-bold text-[10px] cursor-pointer"
                >
                  Remove Card
                </button>
              </div>
            </div>
          </div>
        ) : (
          <div id="flashcards-empty" className="bg-white border border-zinc-200 border-dashed rounded-2xl h-80 flex flex-col items-center justify-center text-center p-6 text-zinc-400 shadow-sm animate-pulse">
            <Layers className="w-10 h-10 mb-2 text-zinc-400" />
            <h4 className="font-semibold text-zinc-700 text-xs">No flashcards found for filter</h4>
            <p className="text-[11px] leading-relaxed max-w-sm mt-1 text-zinc-500">
              Select another familiarity filter, craft custom cards manually above, or write a subject to trigger the AI Generative feature.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
