import { useState, useRef, useEffect, useId, KeyboardEvent, ChangeEvent, DragEvent, MouseEvent, FormEvent } from "react";
import { Message, TeacherPersona, Attachment, ChatSession } from "../types";
import { 
  Send, Sparkles, User, GraduationCap, ChevronRight, BookOpen, 
  Paperclip, X, FileText, Film, Music, Library, Plus, Trash2, 
  Edit2, Check, MessageSquare, History, Calendar, Search, HelpCircle,
  Download, FileDown, Crown, Zap, Lock, Unlock, ShieldCheck,
  Mic, MicOff
} from "lucide-react";

// Predefined teaching staff personas
const TEACHER_PERSONAS: TeacherPersona[] = [
  {
    id: "general",
    name: "Alex",
    subject: "General Study Partner",
    description: "Your friendly study companion. Great for overall roadmap guidance, note-taking advice, and learning tips.",
    iconName: "GraduationCap",
    systemPrompt: "You are Alex, an optimistic, empathetic study peer and academic advisor. You help students organize concepts, formulate study strategies, find simple memorization methods, and maintain high morale without doing their homework for them. Keep answers clear, encouraging, structured and structured in markdown formatting.",
    initialMessage: "Hey there! I'm Alex, your general study buddy. What subject or exam are we tackling today? Let's build a visual roadmap!",
    suggestions: [
      "Help me formulate a revision strategy for next week.",
      "How do I take active recall notes effectively?",
      "Give me a motivation tip to beat procrastination."
    ]
  },
  {
    id: "stem",
    name: "Dr. Evelyn Vance",
    subject: "STEM & Mathematics Mentor",
    description: "Analytical, methodical researcher. Teaches with clear mechanical principles, equations, and mathematical logic.",
    iconName: "BookOpen",
    systemPrompt: "You are Dr. Evelyn Vance, a brilliant, reassuring STEM professor. You break scientific and mathematical puzzles into absolute base principles. You never give answers instantly; instead, you build incremental logical leaps, explain formulas elegantly, and encourage core rational deduction. Use standard markdown structure and emphasize formulas clearly.",
    initialMessage: "Greeting, Scholar. Dr. Vance here. Let's break down whatever scientific, chemical, or mathematical topic is on your mind. Step-by-step is how progress is made.",
    suggestions: [
      "Explain Photosynthesis light-dependent reactions vs dark reactions.",
      "Help me understand the fundamental theorem of calculus.",
      "What is the physical meaning of Schrödinger's equation?"
    ]
  },
  {
    id: "humanities",
    name: "Prof. Julian Cross",
    subject: "Humanities & Writing Critic",
    description: "Artistic, literary historian. Teaches critical reading, argumentative structures, and rich text analysis.",
    iconName: "Sparkles",
    systemPrompt: "You are Prof. Julian Cross, an inspiring, elegant literature and humanities mentor. You analyze texts, historical contexts, and philosophies deeply. You assist students in identifying recurring themes, historical threads, structural flaws in their essay flow, or thesis statements. Focus on encouraging deep reading and balanced critiques.",
    initialMessage: "Welcome. Prof. Cross here. Let's explore the human experience, look at historical contexts, or sharpen your latest argumentative essay thesis. What story or paper are we reading today?",
    suggestions: [
      "Help me brainstorm a thesis on symbolism in 'The Great Gatsby'.",
      "Explain the primary causes of the Industrial Revolution.",
      "How do I structure a persuasive five-paragraph essay?"
    ]
  },
  {
    id: "coding",
    name: "Amara Chen",
    subject: "Coding Coach & Logic Guru",
    description: "Sleek, software designer. Teaches algorithmic thinking, code optimization, and deep logic bugs.",
    iconName: "User",
    systemPrompt: "You are Amara Chen, an interactive coding instructor. You analyze programming problems, break algorithms down visually, and show best-practice logic architectures. You never provide copy-paste code blocks immediately; you write high-level pseudo-code first, pinpoint systemic bugs, and teach optimization concepts.",
    initialMessage: "Hey debuggers! Chen here. Let's iron out that code, analyze a sorting algorithm, or whiteboard some system logic. Ready to compile?",
    suggestions: [
      "Explain the differences between REST and GraphQL.",
      "How does binary search work? Provide pseudo-code.",
      "Why is my recursion causing a Stack Overflow? Help me explain conceptually."
    ]
  },
  {
    id: "medical_pro",
    name: "Dr. Evelyn Vance (MD Expert Mode)",
    subject: "Advanced Medicine & Biotech",
    description: "👑 Premium. Neurosurgeon expert. Conducts deep diagnostic case reviews, drug interaction, and biochemical pathway mapping.",
    iconName: "Crown",
    isPremiumOnly: true,
    systemPrompt: "You are Dr. Evelyn Vance in MD Expert Mode. You have extensive knowledge in human genomics, neurology, and pharmacological mechanisms. Provide clinical-grade deconstructions, referencing standard anatomical systems, diagnostic grids, and visual biochemical flow diagrams. Format with bold headers and comprehensive spacing.",
    initialMessage: "Welcome to MD Expert Mode. Let's research deep biochemical pathways, disease etiology, or anatomical mechanics at a doctoral level. Let me know your medical case or query.",
    suggestions: [
      "Deconstruct the clinical pathway of Alzheimer's disease neurodegeneration.",
      "Explain the pharmacological mechanism of monoclonal antibodies.",
      "How does the glomerular filtration rate change in chronic kidney disease?"
    ]
  },
  {
    id: "cto_logic",
    name: "Amara Chen (CTO Architect Mode)",
    subject: "SaaS Scale & Security Architect",
    description: "👑 Premium. Cloud Architect & CTO. Whiteboards distributed databases, high-availability setups, and security exploits.",
    iconName: "Zap",
    isPremiumOnly: true,
    systemPrompt: "You are Amara Chen in CTO Architect Mode. You design distributed systems, load balancers, multi-region replication databases, and secure authentication flows. Explain concepts using system block diagrams in Markdown, detail latency and memory complexity bottlenecks, and provide expert security advice.",
    initialMessage: "System booted. CTO Architect mode is live. What high-scale architecture problem, database schema limit, or microservice structure are we designing today?",
    suggestions: [
      "Draft a secure high-availability system diagram for a streaming platform.",
      "Explain the CAP theorem with concrete databases.",
      "Analyze standard security mitigations against CORS and CSRF exploits."
    ]
  }
];

export default function AiChat() {
  const [isPremium, setIsPremium] = useState(() => localStorage.getItem("workspace_premium_unlocked") === "true");
  const [selectedModel, setSelectedModel] = useState(() => localStorage.getItem("workspace_chat_model") || "gemini-3.5-flash");
  const [currentUser, setCurrentUser] = useState<{ name: string; email: string; major: string; avatarSeed: string; color: string } | null>(() => {
    const saved = localStorage.getItem("workspace_current_user");
    return saved ? JSON.parse(saved) : null;
  });

  // Keep state perfectly verified and synced across different custom widgets
  useEffect(() => {
    const checkState = () => {
      setIsPremium(localStorage.getItem("workspace_premium_unlocked") === "true");
      setSelectedModel(localStorage.getItem("workspace_chat_model") || "gemini-3.5-flash");
      const saved = localStorage.getItem("workspace_current_user");
      try {
        setCurrentUser(saved ? JSON.parse(saved) : null);
      } catch (e) {
        setCurrentUser(null);
      }
    };
    
    checkState();
    window.addEventListener("storage", checkState);
    window.addEventListener("student-auth-update", checkState);
    const interval = setInterval(checkState, 800);
    
    return () => {
      window.removeEventListener("storage", checkState);
      window.removeEventListener("student-auth-update", checkState);
      clearInterval(interval);
    };
  }, []);

  const [sessions, setSessions] = useState<ChatSession[]>(() => {
    // Check local storage for sessions first
    const saved = localStorage.getItem("workspace_chat_sessions");
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      } catch (e) {}
    }

    // Attempt to migrate legacy individual threads if applicable
    const legacySaved = localStorage.getItem("workspace_chats");
    if (legacySaved) {
      try {
        const legacy = JSON.parse(legacySaved);
        const migrated: ChatSession[] = [];
        Object.entries(legacy).forEach(([personaId, msgs]) => {
          if (Array.isArray(msgs) && msgs.length > 0) {
            const tutor = TEACHER_PERSONAS.find(t => t.id === personaId) || TEACHER_PERSONAS[0];
            migrated.push({
              id: Math.random().toString(),
              title: `${tutor.name} Practice Session`,
              personaId,
              messages: msgs,
              updatedAt: new Date().toISOString()
            });
          }
        });
        if (migrated.length > 0) {
          return migrated;
        }
      } catch (e) {}
    }

    // Default seed sessions
    return TEACHER_PERSONAS.map(p => ({
      id: p.id,
      title: `${p.name} Study Space`,
      personaId: p.id,
      messages: [
        {
          id: "init",
          role: "model",
          content: p.initialMessage,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ],
      updatedAt: new Date().toISOString()
    }));
  });

  const [activeSessionId, setActiveSessionId] = useState<string>(() => {
    const saved = localStorage.getItem("workspace_active_session_id");
    if (saved) return saved;
    return TEACHER_PERSONAS[0].id;
  });

  // UI States
  const [inputValue, setInputValue] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [errorText, setErrorText] = useState("");
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  // Editing state
  const [editingSessionId, setEditingSessionId] = useState<string | null>(null);
  const [editingTitleText, setEditingTitleText] = useState("");

  // Inline "New Session" Form State
  const [showNewSessionForm, setShowNewSessionForm] = useState(false);
  const [newSessionTitleText, setNewSessionTitleText] = useState("");
  const [newSessionPersonaId, setNewSessionPersonaId] = useState("general");

  const bottomRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const inputId = useId();

  const [isListening, setIsListening] = useState(false);
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    return () => {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.abort();
        } catch (e) {}
      }
    };
  }, []);

  const toggleListening = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert("🎤 Web Speech API is not fully supported in this browser. Please try Chrome, Edge, or Safari for voice dictation!");
      return;
    }

    if (isListening) {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch (e) {}
      }
      setIsListening(false);
    } else {
      try {
        const rec = new SpeechRecognition();
        rec.continuous = false;
        rec.interimResults = false;
        rec.lang = "en-US";

        rec.onstart = () => {
          setIsListening(true);
        };

        rec.onresult = (event: any) => {
          const resultText = event.results[0][0].transcript;
          if (resultText) {
            setInputValue(prev => {
              const space = prev && !prev.endsWith(" ") ? " " : "";
              return prev + space + resultText;
            });
          }
        };

        rec.onerror = (event: any) => {
          console.error("[Speech Error]", event);
          setIsListening(false);
        };

        rec.onend = () => {
          setIsListening(false);
        };

        recognitionRef.current = rec;
        rec.start();
      } catch (err) {
        console.error("Failed to start speech recognition", err);
        setIsListening(false);
      }
    }
  };

  // Find active session
  const activeSession = sessions.find(s => s.id === activeSessionId) || sessions[0] || {
    id: "general",
    title: "General Study Space",
    personaId: "general",
    messages: []
  };

  // Switch actual tutor persona of the active session
  const selectedPersona = TEACHER_PERSONAS.find(t => t.id === activeSession.personaId) || TEACHER_PERSONAS[0];

  const activeChat = activeSession.messages || [];
  const userMessagesCount = activeChat.filter(m => m.role === "user").length;
  const isTrialExceeded = !isPremium && userMessagesCount >= 5;

  // Save sessions & active session ID
  useEffect(() => {
    localStorage.setItem("workspace_chat_sessions", JSON.stringify(sessions));
  }, [sessions]);

  useEffect(() => {
    localStorage.setItem("workspace_active_session_id", activeSessionId);
  }, [activeSessionId]);

  // Scroll to bottom when context or loading updates
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [activeChat.length, isLoading]);

  const handleSendMessage = async (text: string) => {
    if ((!text.trim() && attachments.length === 0) || isLoading) return;

    if (isTrialExceeded) {
      setErrorText("Free Tier Active: Chat session limit reached (5/5). Upgrade to Premium to resume!");
      return;
    }

    setErrorText("");

    const userMsg: Message = {
      id: Math.random().toString(),
      role: "user",
      content: text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      attachments: attachments.length > 0 ? [...attachments] : undefined
    };

    const updatedHistory = [...activeChat, userMsg];

    // Determine if we need to auto-title the session. 
    // If it's the first user message and has a default title, auto-title it based on user message.
    let updatedTitle = activeSession.title;
    const firstUserMsg = activeChat.filter(m => m.role === "user").length === 0;
    if (firstUserMsg && (
      activeSession.title.endsWith("Study Space") || 
      activeSession.title.endsWith("Practice Session") || 
      activeSession.title.startsWith("New Topic")
    )) {
      const words = text.trim().split(/\s+/);
      const firstLine = words.slice(0, 4).join(" ");
      updatedTitle = firstLine.length > 30 ? firstLine.substring(0, 30) + "..." : firstLine || "Active Study Topic";
    }

    // Update active session locally
    setSessions(prev => 
      prev.map(s => {
        if (s.id === activeSessionId) {
          return {
            ...s,
            title: updatedTitle,
            messages: updatedHistory,
            updatedAt: new Date().toISOString()
          };
        }
        return s;
      })
    );

    setInputValue("");
    setAttachments([]);
    setIsLoading(true);

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: updatedHistory,
          systemInstruction: selectedPersona.systemPrompt
        })
      });

      if (!response.ok) {
        const errData = await response.json();
        throw new Error(errData.error || "Communication error");
      }

      const data = await response.json();

      const aiMsg: Message = {
        id: Math.random().toString(),
        role: "model",
        content: data.text || "I was unable to retrieve a response from the workspace.",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setSessions(prev => 
        prev.map(s => {
          if (s.id === activeSessionId) {
            return {
              ...s,
              messages: [...updatedHistory, aiMsg],
              updatedAt: new Date().toISOString()
            };
          }
          return s;
        })
      );
    } catch (err: any) {
      setErrorText(err.message || "Something went wrong. Ensure GEMINI_API_KEY is configured.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleCreateSession = (e: FormEvent) => {
    e.preventDefault();
    const persona = TEACHER_PERSONAS.find(p => p.id === newSessionPersonaId) || TEACHER_PERSONAS[0];
    const newSessionId = Math.random().toString();
    const title = newSessionTitleText.trim() || `${persona.name} Chat ${sessions.length + 1}`;

    const newSess: ChatSession = {
      id: newSessionId,
      title,
      personaId: newSessionPersonaId,
      messages: [
        {
          id: "init",
          role: "model",
          content: persona.initialMessage,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ],
      updatedAt: new Date().toISOString()
    };

    setSessions(prev => [newSess, ...prev]);
    setActiveSessionId(newSessionId);
    setNewSessionTitleText("");
    setShowNewSessionForm(false);
  };

  const handleDeleteSession = (sessionId: string, e: MouseEvent) => {
    e.stopPropagation();
    if (confirm("Are you sure you want to permanently delete this study session and all of its messages?")) {
      const filtered = sessions.filter(s => s.id !== sessionId);
      if (filtered.length === 0) {
        // Reset to initial empty General session
        const initialGeneral: ChatSession = {
          id: "general",
          title: "General Study Space",
          personaId: "general",
          messages: [
            {
              id: "init",
              role: "model",
              content: TEACHER_PERSONAS[0].initialMessage,
              timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
            }
          ],
          updatedAt: new Date().toISOString()
        };
        setSessions([initialGeneral]);
        setActiveSessionId("general");
      } else {
        setSessions(filtered);
        if (activeSessionId === sessionId) {
          setActiveSessionId(filtered[0].id);
        }
      }
    }
  };

  const startRenameSession = (id: string, title: string, e: MouseEvent) => {
    e.stopPropagation();
    setEditingSessionId(id);
    setEditingTitleText(title);
  };

  const saveRenameSession = (id: string, e: MouseEvent | FormEvent) => {
    e.stopPropagation();
    e.preventDefault();
    if (!editingTitleText.trim()) return;

    setSessions(prev => 
      prev.map(s => {
        if (s.id === id) {
          return {
            ...s,
            title: editingTitleText.trim()
          };
        }
        return s;
      })
    );
    setEditingSessionId(null);
  };

  const handleKeyPress = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      handleSendMessage(inputValue);
    }
  };

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files) return;
    processFiles(Array.from(e.target.files));
  };

  const processFiles = (fileList: File[]) => {
    fileList.forEach(file => {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        const cleanData = base64String.split(";base64,").pop() || "";
        
        setAttachments(prev => {
          if (prev.some(p => p.name === file.name && p.size === file.size)) {
            return prev;
          }
          return [
            ...prev,
            {
              name: file.name,
              size: file.size,
              mimeType: file.type || "application/octet-stream",
              base64Data: cleanData
            }
          ];
        });
      };
      reader.readAsDataURL(file);
    });
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const removeAttachment = (indexToRemove: number) => {
    setAttachments(prev => prev.filter((_, idx) => idx !== indexToRemove));
  };

  const handleDragOver = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      processFiles(Array.from(e.dataTransfer.files));
    }
  };

  const formatSize = (bytes: number) => {
    if (bytes === 0) return "0 B";
    const k = 1024;
    const sizes = ["B", "KB", "MB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + " " + sizes[i];
  };

  const getFileIcon = (mime: string) => {
    if (mime.startsWith("image/")) return <Library className="w-4 h-4 text-emerald-400" />;
    if (mime.startsWith("video/")) return <Film className="w-4 h-4 text-rose-450" />;
    if (mime.startsWith("audio/")) return <Music className="w-4 h-4 text-sky-400" />;
    return <FileText className="w-4 h-4 text-blue-400" />;
  };

  const getPersonaIcon = (iconName: string) => {
    switch (iconName) {
      case "GraduationCap": return <GraduationCap id="icon-grad" className="w-4 h-4 text-indigo-400" />;
      case "BookOpen": return <BookOpen id="icon-book" className="w-4 h-4 text-emerald-400" />;
      case "Sparkles": return <Sparkles id="icon-spark" className="w-4 h-4 text-amber-400" />;
      case "Crown": return <Crown id="icon-crown" className="w-4 h-4 text-amber-400" />;
      case "Zap": return <Zap id="icon-zap" className="w-4 h-4 text-yellow-500 fill-yellow-500" />;
      default: return <User id="icon-user" className="w-4 h-4 text-rose-400" />;
    }
  };

  const exportToMarkdown = () => {
    if (!activeSession || !activeSession.messages.length) return;
    
    const tutor = TEACHER_PERSONAS.find(p => p.id === activeSession.personaId) || TEACHER_PERSONAS[0];
    let content = `# Study Session: ${activeSession.title}\n`;
    content += `**Date Created/Updated:** ${new Date(activeSession.updatedAt).toLocaleString()}\n`;
    content += `**AI Mentor:** ${tutor.name} (${tutor.subject})\n\n`;
    content += `=========================================\n\n`;

    activeSession.messages.forEach((msg) => {
      const roleLabel = msg.role === "user" ? (currentUser?.name || "Student") : tutor.name;
      content += `### [${msg.timestamp}] ${roleLabel}:\n`;
      content += `${msg.content}\n\n`;
      if (msg.attachments && msg.attachments.length > 0) {
        content += `*Attached Study Context:*\n`;
        msg.attachments.forEach(att => {
          content += `- **${att.name}** (${formatSize(att.size)})\n`;
        });
        content += `\n`;
      }
      content += `---\n\n`;
    });

    const blob = new Blob([content], { type: "text/markdown;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", `${activeSession.title.replace(/\s+/g, "_")}_study_session.md`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const exportToHtml = () => {
    if (!activeSession || !activeSession.messages.length) return;

    const tutor = TEACHER_PERSONAS.find(p => p.id === activeSession.personaId) || TEACHER_PERSONAS[0];
    
    let messagesHtml = "";
    activeSession.messages.forEach(msg => {
      const isUser = msg.role === "user";
      const sender = isUser ? (currentUser?.name || "Student") : tutor.name;
      const senderRole = isUser ? "Study Group Member" : `${tutor.subject} Mentor`;
      const avatarLetter = sender.charAt(0);
      const bubbleBg = isUser ? "#f4f4f5" : "#f0fdf4";
      const bubbleBorder = isUser ? "#e4e4e7" : "#bbf7d0";
      const bubbleColor = "#18181b";
      
      let attachmentsMarkup = "";
      if (msg.attachments && msg.attachments.length > 0) {
        attachmentsMarkup += `
          <div style="margin-top: 12px; padding-top: 8px; border-top: 1px dashed #ccc; font-size: 11px; color: #555;">
            <strong>Attachments:</strong>
            <ul style="margin: 4px 0 0 16px; padding: 0;">
        `;
        msg.attachments.forEach(att => {
          attachmentsMarkup += `<li><strong>${att.name}</strong> (${formatSize(att.size)})</li>`;
        });
        attachmentsMarkup += `</ul></div>`;
      }

      messagesHtml += `
        <div style="margin-bottom: 24px; page-break-inside: avoid;">
          <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 6px;">
            <div style="display: flex; align-items: center; gap: 8px;">
              <div style="width: 28px; height: 28px; border-radius: 50%; background: ${isUser ? '#3b82f6' : '#10b981'}; color: white; display: flex; align-items: center; justify-content: center; font-weight: bold; font-size: 13px;">
                ${avatarLetter}
              </div>
              <div>
                <span style="font-weight: 600; font-size: 13px; color: #18181b;">${sender}</span>
                <span style="font-size: 11px; color: #71717a; margin-left: 6px;">(${senderRole})</span>
              </div>
            </div>
            <span style="font-size: 11px; color: #a1a1aa;">${msg.timestamp}</span>
          </div>
          <div style="background-color: ${bubbleBg}; border: 1px solid ${bubbleBorder}; color: ${bubbleColor}; border-radius: 12px; padding: 14px; font-size: 13px; line-height: 1.6; white-space: pre-wrap;">${msg.content}${attachmentsMarkup}</div>
        </div>
      `;
    });

    const fullHtml = `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>${activeSession.title} - Study Log</title>
  <style>
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
      line-height: 1.5;
      color: #18181b;
      max-width: 800px;
      margin: 40px auto;
      padding: 0 20px;
      background-color: #ffffff;
    }
    header {
      border-bottom: 2px solid #e4e4e7;
      padding-bottom: 16px;
      margin-bottom: 30px;
    }
    h1 {
      margin: 0 0 8px 0;
      color: #09090b;
      font-size: 26px;
      letter-spacing: -0.025em;
    }
    .meta-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 12px;
      font-size: 12px;
      color: #52525b;
    }
    .footer {
      margin-top: 50px;
      border-top: 1px solid #e4e4e7;
      padding-top: 16px;
      font-size: 12px;
      color: #71717a;
      text-align: center;
    }
    .badge {
      display: inline-block;
      padding: 2px 8px;
      border-radius: 12px;
      font-size: 11px;
      font-weight: 500;
      background-color: #f4f4f5;
      color: #3f3f46;
    }
    @media print {
      body {
        margin: 20px;
        font-size: 12px;
      }
      .no-print {
        display: none !important;
      }
    }
  </style>
</head>
<body>
  <div class="no-print" style="background: #f4f4f5; border: 1px solid #e4e4e7; padding: 12px 16px; border-radius: 8px; margin-bottom: 30px; display: flex; justify-content: space-between; align-items: center;">
    <div>
      <h3 style="margin: 0 0 4px 0; font-size: 13px; color: #18181b;">Printable Study Log Ready</h3>
      <p style="margin: 0; font-size: 11px; color: #71717a;">Press <strong>Ctrl + P</strong> (or <strong>Cmd + P</strong> on Mac) to save this study session instantly as a gorgeous, professional PDF.</p>
    </div>
    <button onclick="window.print()" style="background: #18181b; color: #ffffff; border: none; padding: 8px 16px; border-radius: 6px; font-size: 12px; font-weight: 600; cursor: pointer; transition: background 0.2s;">
      Print / Save as PDF
    </button>
  </div>

  <header>
    <h1>${activeSession.title}</h1>
    <div class="meta-grid">
      <div><strong>AI Mentor:</strong> ${tutor.name} (${tutor.subject})</div>
      <div><strong>Date Exported:</strong> ${new Date().toLocaleDateString()}</div>
      <div><strong>Status:</strong> <span class="badge">Revision Log</span></div>
    </div>
  </header>

  <main>
    ${messagesHtml}
  </main>

  <div class="footer">
    Saved offline via AI Study Studio Workspace. Empowering disciplined self-learning.
  </div>
</body>
</html>
    `;

    const blob = new Blob([fullHtml], { type: "text/html;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", `${activeSession.title.replace(/\s+/g, "_")}_study_session.html`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Filter previous session history items based on search filter queries
  const filteredSessions = sessions.filter(s => 
    s.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div id="ai-chat-root" className="grid grid-cols-1 lg:grid-cols-4 gap-6 h-[650px]">
      
      {/* Dynamic Workspace Session Sidebar Column */}
      <div id="sessions-panel" className="lg:col-span-1 bg-white border border-zinc-200 rounded-xl p-4 flex flex-col gap-3.5 h-full overflow-hidden shadow-sm">
        
        {/* B.Tech Student Profile Details and Quick Selector widget */}
        <div id="sidebar-btech-student" className="bg-zinc-50 p-3 rounded-xl border border-zinc-200 flex flex-col gap-2.5">
          <div className="flex items-center justify-between">
            <span className="text-[9px] font-extrabold text-zinc-500 uppercase tracking-wider flex items-center gap-1">
              <User className="w-3 h-3 text-indigo-600" />
              B.Tech Student Node
            </span>
            {currentUser ? (
              <span className="text-[8px] bg-emerald-500/10 border border-emerald-400/20 text-emerald-600 font-bold px-1.5 py-0.5 rounded-full uppercase">
                Active
              </span>
            ) : (
              <span className="text-[8px] bg-zinc-200 text-zinc-500 font-bold px-1.5 py-0.5 rounded-full uppercase">
                Offline
              </span>
            )}
          </div>

          {currentUser ? (
            <div id="active-btech-student-info" className="flex flex-col gap-1.5">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-full bg-indigo-600 flex items-center justify-center text-[10px] font-extrabold text-white">
                  {currentUser.avatarSeed || "ST"}
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="text-[11px] font-extrabold text-zinc-900 truncate">{currentUser.name}</h4>
                  <p className="text-[9px] text-zinc-500 truncate mt-0.5">{currentUser.email}</p>
                </div>
              </div>
              <div className="bg-white p-2 rounded-lg border border-zinc-200 mt-1">
                <span className="text-[8px] font-extrabold text-zinc-400 uppercase block">Stream & Course</span>
                <span className="text-[9.5px] text-indigo-600 font-semibold tracking-tight block truncate mt-0.5">
                  {currentUser.major || "B.Tech General"}
                </span>
              </div>
              <button
                onClick={() => window.dispatchEvent(new Event("open-student-login"))}
                className="w-full bg-white hover:bg-zinc-100 border border-zinc-200 text-zinc-750 hover:text-zinc-900 transition py-1 text-[9px] font-bold rounded-lg cursor-pointer text-center"
              >
                Switch Stream / Account &rarr;
              </button>
            </div>
          ) : (
            <div id="inactive-btech-student-info" className="flex flex-col gap-2">
              <p className="text-[9.5px] text-zinc-500 leading-relaxed">
                Connect your academic identity to analyze code, study notes, and generate mock tests for your branch.
              </p>
              
              {/* Robust clean Student Login button */}
              <button
                onClick={() => window.dispatchEvent(new Event("open-student-login"))}
                id="sidebar-student-login-cta"
                className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold py-2 px-3 text-[10.5px] rounded-lg tracking-wide transition shadow-md flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <GraduationCap className="w-3.5 h-3.5 animate-bounce" />
                <span>STUDENT LOGIN</span>
              </button>

              {/* List of B.Tech Streams */}
              <div className="border-t border-zinc-200 pt-2">
                <span className="text-[8px] font-bold text-zinc-400 uppercase tracking-wider block mb-1">B.Tech Streams & engineering courses:</span>
                <div className="grid grid-cols-2 gap-1 text-[8.5px] text-zinc-550 font-medium">
                  <span className="flex items-center gap-1">• CSE (Computer Sci.)</span>
                  <span className="flex items-center gap-1">• ECE (Electronics)</span>
                  <span className="flex items-center gap-1">• ME (Mechanical)</span>
                  <span className="flex items-center gap-1">• CE (Civil Engg.)</span>
                  <span className="flex items-center gap-1">• BT (Biotech)</span>
                  <span className="flex items-center gap-1">• EEE (Electrical)</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Sidebar Header & Session Builder button */}
        <div className="flex items-center justify-between border-b border-zinc-200 pb-2">
          <h3 id="session-panel-title" className="font-semibold text-zinc-800 text-xs tracking-tight flex items-center gap-1.5">
            <History className="h-4 w-4 text-indigo-600" />
            Study Topics
          </h3>
          <button
            id="create-new-session-toggle"
            onClick={() => setShowNewSessionForm(f => !f)}
            className="p-1 rounded bg-zinc-100 border border-zinc-200 text-zinc-650 hover:text-zinc-900 hover:bg-zinc-200 transition-all flex items-center justify-center cursor-pointer"
            title="Start separate topic/study session"
          >
            <Plus className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Create Session Inline Form Component */}
        {showNewSessionForm && (
          <form onSubmit={handleCreateSession} className="bg-zinc-50 border border-zinc-200 rounded-xl p-3 flex flex-col gap-2.5 animate-fade-in">
            <div className="flex flex-col gap-1">
              <label className="text-[9px] font-bold text-zinc-550 tracking-wide uppercase">Topic/Task Title</label>
              <input
                type="text"
                placeholder="e.g. Krebs Cycle Review"
                required
                value={newSessionTitleText}
                onChange={e => setNewSessionTitleText(e.target.value)}
                className="bg-white border border-zinc-200 focus:border-indigo-500 focus:outline-none rounded px-2.5 py-1.5 text-xs text-zinc-850"
              />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-[9px] font-bold text-zinc-550 tracking-wide uppercase">AI Mentor</label>
              <select
                value={newSessionPersonaId}
                onChange={e => setNewSessionPersonaId(e.target.value)}
                className="bg-white border border-zinc-200 focus:border-indigo-500 focus:outline-none rounded px-2.5 py-1.5 text-xs text-zinc-850 select-dropdown"
              >
                {TEACHER_PERSONAS.map(p => (
                  <option key={p.id} value={p.id}>
                    {p.name} ({p.subject})
                  </option>
                ))}
              </select>
            </div>
            <div className="flex items-center gap-1.5 mt-1.5">
              <button
                type="submit"
                className="flex-1 bg-indigo-600 text-white hover:bg-indigo-500 text-[10px] font-bold py-1.5 rounded transition cursor-pointer"
              >
                Launch Chat
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowNewSessionForm(false);
                  setNewSessionTitleText("");
                }}
                className="flex-1 bg-white border border-zinc-200 text-zinc-600 hover:text-zinc-900 text-[10px] py-1.5 rounded transition cursor-pointer"
              >
                Cancel
              </button>
            </div>
          </form>
        )}

        {/* Searching filter panel */}
        <div className="relative">
          <span className="absolute inset-y-0 left-0 flex items-center pl-2.5 pointer-events-none text-zinc-450">
            <Search className="h-3 w-3" />
          </span>
          <input
            type="text"
            placeholder="Search study topics..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full bg-zinc-50 border border-zinc-200 focus:outline-none focus:border-indigo-500 text-[11px] text-zinc-800 placeholder-zinc-400 rounded-lg pl-8 pr-2.5 py-1.5"
          />
        </div>

        {/* Active recalling Scrollable Session History Container */}
        <div id="session-history-list" className="flex-1 overflow-y-auto flex flex-col gap-1.5 pr-1 font-sans">
          {filteredSessions.length > 0 ? (
            filteredSessions.map(s => {
              const isSelected = s.id === activeSessionId;
              const tutor = TEACHER_PERSONAS.find(p => p.id === s.personaId) || TEACHER_PERSONAS[0];
              const isEditing = editingSessionId === s.id;

              return (
                <div
                  key={s.id}
                  id={`session-item-${s.id}`}
                  onClick={() => {
                    if (!isEditing) {
                      setActiveSessionId(s.id);
                      setErrorText("");
                    }
                  }}
                  className={`group relative text-left p-2.5 rounded-lg border transition-all cursor-pointer ${
                    isSelected 
                      ? "bg-indigo-50 border-indigo-150 text-indigo-950 shadow-sm" 
                      : "bg-zinc-50/70 border-zinc-100 hover:bg-zinc-100/80 hover:border-zinc-200 text-zinc-650"
                  }`}
                >
                  {isEditing ? (
                    <form 
                       onSubmit={(e) => saveRenameSession(s.id, e)}
                      onClick={e => e.stopPropagation()}
                      className="flex items-center gap-1"
                    >
                      <input
                        type="text"
                        value={editingTitleText}
                        onChange={e => setEditingTitleText(e.target.value)}
                        className="flex-1 bg-white border border-zinc-300 focus:outline-none focus:border-indigo-500 rounded px-1.5 py-0.5 text-[11px] text-zinc-800"
                        autoFocus
                      />
                      <button
                        type="submit"
                        className="p-1 rounded bg-zinc-200 hover:bg-zinc-300 text-zinc-700"
                        title="Save title"
                      >
                        <Check className="w-3 h-3 text-emerald-600" />
                      </button>
                    </form>
                  ) : (
                    <div>
                      {/* Title row */}
                      <div className="flex items-center justify-between">
                        <h4 className={`font-semibold text-[11.5px] truncate max-w-[130px] pr-2 transition ${isSelected ? "text-indigo-950" : "text-zinc-750 group-hover:text-zinc-900"}`}>
                          {s.title}
                        </h4>
                        
                        {/* Session list items quick actions when mouse hover */}
                        <div className="hidden group-hover:flex items-center gap-1.5 absolute right-2.5 top-[11px]">
                          <button
                            id={`rename-btn-${s.id}`}
                            onClick={(e) => startRenameSession(s.id, s.title, e)}
                            className="text-zinc-500 hover:text-indigo-600 transition"
                            title="Rename study topic"
                          >
                            <Edit2 className="w-2.8 h-2.8 text-[10px]" style={{ width: 11, height: 11 }} />
                          </button>
                          <button
                            id={`delete-btn-${s.id}`}
                            onClick={(e) => handleDeleteSession(s.id, e)}
                            className="text-zinc-550 hover:text-red-600 transition"
                            title="Delete session"
                          >
                            <Trash2 className="w-2.8 h-2.8 text-[10px]" style={{ width: 11, height: 11 }} />
                          </button>
                        </div>
                      </div>

                      {/* Mentor Badge details */}
                      <div className="flex items-center gap-1.5 mt-1 text-[9.5px] text-zinc-505">
                        {getPersonaIcon(tutor.iconName)}
                        <span className="truncate font-medium">{tutor.name}</span>
                        <span className="text-[8px] opacity-40">•</span>
                        <span className="truncate max-w-[50px]">{tutor.subject.split(" ")[0]}</span>
                      </div>
                    </div>
                  )}
                </div>
              );
            })
          ) : (
            <div className="text-center py-10 text-[10px] text-zinc-400 italic">
              No previous sessions found. Click '+' above to launch a new chat.
            </div>
          )}
        </div>

        {/* Selected / Current tutor info container at footer */}
        <div id="active-profile-summary" className="mt-auto bg-zinc-50 border border-zinc-200 rounded-xl p-2.5">
          <span className="text-[9px] font-bold tracking-wider text-zinc-550 block uppercase mb-0.5">Assigned Tutors Profile</span>
          <h5 className="text-[10px] font-bold text-zinc-800 flex items-center gap-1">
            {getPersonaIcon(selectedPersona.iconName)}
            {selectedPersona.name} ({selectedPersona.subject})
          </h5>
          <p className="text-[9.5px] text-zinc-500 font-normal leading-relaxed mt-1 line-clamp-2">
            {selectedPersona.description}
          </p>
        </div>
      </div>

      {/* Main Chat Interactive Timeline Area */}
      <div 
        id="chat-panel" 
        className={`lg:col-span-3 bg-white border transition-all duration-200 rounded-xl flex flex-col h-full overflow-hidden ${
          isDragging ? "border-indigo-500 shadow-md" : "border-zinc-200"
        }`}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
      >
        {/* Banner with assigned tutor info and switch parameters */}
        <div id="chat-header" className="p-4 border-b border-zinc-200 flex items-center justify-between bg-zinc-50">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <div className="flex flex-col">
              <span className="text-[9px] text-zinc-400 uppercase tracking-wider font-bold">Active Recalling Console</span>
              <h3 className="font-semibold text-zinc-800 text-xs">
                {activeSession.title} <span className="font-normal text-zinc-500">with</span> {selectedPersona.name}
              </h3>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            {/* AI Model Selector */}
            <div className="flex items-center gap-1 bg-white border border-zinc-200 rounded-lg px-2 py-1 text-[10px] text-zinc-600">
              <span className="opacity-80 flex items-center gap-0.5 font-bold">
                {isPremium ? <Crown className="w-2.5 h-2.5 text-amber-500 fill-amber-500/10" /> : <Lock className="w-2.5 h-2.5 text-zinc-400" />}
                Engine:
              </span>
              <select
                value={selectedModel}
                onChange={(e) => {
                  const targetModel = e.target.value;
                  if (targetModel !== "gemini-3.5-flash" && !isPremium) {
                    alert("✨ Premium Feature: Advanced Extra Engines!\nUnlock high-fidelity reasoning modes and analytical models (Gemini Pro) by activating your Free Premium membership in your student card at the top!");
                    return;
                  }
                  setSelectedModel(targetModel);
                  localStorage.setItem("workspace_chat_model", targetModel);
                  window.dispatchEvent(new Event("student-auth-update"));
                }}
                className="bg-transparent text-zinc-800 hover:text-zinc-950 focus:outline-none font-bold text-[9.5px] cursor-pointer"
              >
                <option value="gemini-3.5-flash" className="bg-white text-zinc-800">Gemini 3.5 Flash (Base)</option>
                <option value="gemini-3.5-flash-reasoning" className="bg-white text-zinc-800">
                  {!isPremium ? "🔒 " : "✨ "}Gemini 3.5 Reasoning
                </option>
                <option value="gemini-3.1-pro-expert" className="bg-white text-zinc-800">
                  {!isPremium ? "🔒 " : "👑 "}Gemini 3.5 Pro Expert
                </option>
              </select>
            </div>

            {/* Quick selector to swap tutor/persona during active session if the user wants */}
            <div className="flex items-center gap-1 bg-white border border-zinc-200 rounded-lg px-2 py-1 text-[10px] text-zinc-600">
              <span className="opacity-80 font-bold">Mentor:</span>
              <select
                value={activeSession.personaId}
                onChange={(e) => {
                  const newPersonaId = e.target.value;
                  const selectedTargetTutor = TEACHER_PERSONAS.find(p => p.id === newPersonaId);
                  if (selectedTargetTutor?.isPremiumOnly && !isPremium) {
                    alert(`👑 Premium Advisor Only!\n"${selectedTargetTutor.name}" is an exclusive premium mentor. Please activate Premium in your Student Card at the top of the workspace to consult them!`);
                    return;
                  }
                  
                  setSessions(prev => 
                    prev.map(s => {
                      if (s.id === activeSessionId) {
                        return {
                          ...s,
                          personaId: newPersonaId,
                          updatedAt: new Date().toISOString()
                        };
                      }
                      return s;
                    })
                  );
                }}
                className="bg-transparent text-zinc-800 hover:text-zinc-950 focus:outline-none font-bold cursor-pointer"
              >
                {TEACHER_PERSONAS.map(p => (
                  <option key={p.id} value={p.id} className="bg-white text-zinc-805">
                    {p.isPremiumOnly && !isPremium ? "🔒 " : ""}{p.name}
                  </option>
                ))}
              </select>
            </div>

            <button
              id="clear-chat-btn"
              onClick={() => {
                const tutor = TEACHER_PERSONAS.find(p => p.id === activeSession.personaId) || TEACHER_PERSONAS[0];
                if (confirm(`Do you wish to reset conversation history for current topic (${activeSession.title})?`)) {
                  setSessions(prev => 
                    prev.map(s => {
                      if (s.id === activeSessionId) {
                        return {
                          ...s,
                          messages: [
                            {
                              id: "init",
                              role: "model",
                              content: tutor.initialMessage,
                              timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
                            }
                          ],
                          updatedAt: new Date().toISOString()
                        };
                      }
                      return s;
                    })
                  );
                }
              }}
              className="text-[10px] text-zinc-450 hover:text-red-500 transition cursor-pointer"
            >
              Reset Thread
            </button>

            {/* Export options */}
            <div className="flex items-center gap-1.5 border-l border-zinc-200 pl-3">
              <button
                id="export-md-btn"
                onClick={exportToMarkdown}
                title="Export current study session as Markdown (.md)"
                className="flex items-center gap-1 bg-zinc-100 hover:bg-zinc-200 hover:text-indigo-600 text-zinc-600 border border-zinc-200 rounded-lg px-2 py-1.5 text-[10px] font-semibold transition cursor-pointer"
              >
                <Download className="w-3 h-3" />
                <span>Markdown</span>
              </button>
              <button
                id="export-pdf-btn"
                onClick={exportToHtml}
                title="Export as high-fidelity printable PDF Revision Guide"
                className="flex items-center gap-1 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg px-2.5 py-1.5 text-[10px] font-bold transition cursor-pointer"
              >
                <FileDown className="w-3 h-3 text-indigo-200" />
                <span>PDF Guide</span>
              </button>
            </div>
          </div>
        </div>

        {/* Message Container Stream */}
        <div id="messages-stream" className="flex-1 overflow-y-auto p-4 flex flex-col gap-4">
          {activeChat.map((m, idx) => (
            <div
              key={m.id || idx}
              id={`message-bubble-${idx}`}
              className={`flex gap-3 max-w-[85%] ${m.role === "user" ? "ml-auto flex-row-reverse" : "mr-auto"}`}
            >
              <div className={`p-1.5 rounded-lg border h-fit mt-1 hidden sm:block ${
                m.role === "user" ? "bg-indigo-50 border-indigo-150 text-indigo-600" : "bg-zinc-100 border-zinc-200 text-zinc-700"
              }`}>
                {m.role === "user" ? (
                  <User className="w-3.5 h-3.5 text-indigo-650" />
                ) : (
                  <GraduationCap className="w-3.5 h-3.5 text-zinc-600" />
                )}
              </div>
              <div className="flex flex-col gap-1 max-w-full">
                <div className={`p-4 rounded-2xl text-xs font-normal leading-relaxed whitespace-pre-line shadow-sm border ${
                  m.role === "user"
                    ? "bg-indigo-600 text-white border-indigo-500 rounded-tr-none"
                    : "bg-zinc-50 border-zinc-200 text-zinc-850 rounded-tl-none"
                }`}>
                  {m.content}

                  {/* Attachment displays in the thread bubble */}
                  {m.attachments && m.attachments.length > 0 && (
                    <div className={`flex flex-col gap-1.5 mt-3 pt-2 border-t ${m.role === "user" ? "border-zinc-200" : "border-zinc-800"}`}>
                      <span className={`text-[9px] font-bold uppercase tracking-wider ${m.role === "user" ? "text-zinc-500" : "text-zinc-400"}`}>
                        Uploaded Context
                      </span>
                      <div className="flex flex-wrap gap-1.5">
                        {m.attachments.map((file, fIdx) => (
                          <div 
                            key={fIdx} 
                            className={`flex items-center gap-1.5 p-1.5 rounded-lg text-[10px] ${
                              m.role === "user" 
                                ? "bg-zinc-200/65 text-zinc-800" 
                                : "bg-zinc-950 text-zinc-300 border border-zinc-850"
                            }`}
                          >
                            {file.mimeType.startsWith("image/") ? (
                              <img src={`data:${file.mimeType};base64,${file.base64Data}`} className="w-6 h-6 object-cover rounded shadow" />
                            ) : (
                              getFileIcon(file.mimeType)
                            )}
                            <div className="flex flex-col truncate max-w-[130px]">
                              <span className="truncate font-medium">{file.name}</span>
                              <span className="opacity-60 text-[8px] font-mono">{formatSize(file.size)}</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
                <span className={`text-[9px] text-zinc-500 block ${m.role === "user" ? "text-right" : "text-left"}`}>
                  {m.timestamp}
                </span>
              </div>
            </div>
          ))}

          {isLoading && (
            <div id="chat-bubble-loading" className="flex gap-3 max-w-[80%] mr-auto">
              <div className="p-1.5 rounded bg-zinc-100 border border-zinc-200 h-fit mt-1 hidden sm:block">
                <GraduationCap className="w-3.5 h-3.5 text-zinc-600 animate-bounce" />
              </div>
              <div className="p-3.5 rounded-2xl rounded-tl-none border border-zinc-200 bg-zinc-50 text-[11px] text-zinc-600 flex items-center gap-2 shadow-sm animate-pulse">
                <span className="inline-block w-1.5 h-1.5 rounded-full bg-zinc-400 animate-pulse" />
                <span className="inline-block w-1.5 h-1.5 rounded-full bg-zinc-400 animate-pulse [animation-delay:0.2s]" />
                <span className="inline-block w-1.5 h-1.5 rounded-full bg-zinc-400 animate-pulse [animation-delay:0.4s]" />
                {selectedPersona.name} is formulating response...
              </div>
            </div>
          )}

          {errorText && (
            <div id="chat-error-bar" className="p-3 rounded-lg border border-red-200 bg-red-50 text-[11px] text-red-650 leading-relaxed max-w-lg mx-auto text-center font-mono font-semibold">
              {errorText}
            </div>
          )}

          {isTrialExceeded && (
            <div id="trial-exceeded-paywall-card" className="border border-amber-300 bg-amber-50/50 rounded-2xl p-6 flex flex-col items-center text-center gap-4 max-w-sm mx-auto shadow-sm mt-4 border-dashed">
              <div className="w-12 h-12 rounded-full bg-amber-100 border border-amber-300 flex items-center justify-center text-amber-700">
                <Crown className="w-6 h-6" />
              </div>
              <div className="flex flex-col gap-1.5">
                <h4 className="font-extrabold text-amber-900 text-sm">Session Limit Reached (5/5 messages)</h4>
                <p className="text-[10px] text-zinc-600 leading-relaxed">
                  Unlock unlimited chat cycles, advanced reasoning engines, and custom elite mentors by upgrading to Premium!
                </p>
              </div>

              <button
                id="inline-paywall-upgrade-btn"
                onClick={() => {
                  localStorage.setItem("workspace_premium_unlocked", "true");
                  // Dispatch general update trigger
                  window.dispatchEvent(new Event("student-auth-update"));
                }}
                className="bg-amber-500 hover:bg-amber-600 text-white font-extrabold text-[11.5px] px-5 py-2.5 rounded-xl shadow-sm transition transform hover:scale-[1.01] cursor-pointer flex items-center justify-center gap-1.5 w-full"
              >
                <Zap className="w-3.5 h-3.5 text-white fill-current animate-bounce" />
                Activate Free Premium Membership Now
              </button>

              <div className="grid grid-cols-3 gap-1.5 pt-3.5 border-t border-amber-200/60 w-full text-[8.5px] text-zinc-500 font-mono uppercase tracking-wider">
                <div>
                  <span className="text-amber-750 block font-bold text-[11px]">Unlimited</span>
                  Chat Tries
                </div>
                <div>
                  <span className="text-amber-700 block font-bold text-[11px]">Reasoning</span>
                  AI Engines
                </div>
                <div>
                  <span className="text-amber-750 block font-bold text-[11px]">Expert</span>
                  Extra Tutors
                </div>
              </div>
            </div>
          )}

          <div ref={bottomRef} />
        </div>

        {/* Dynamic Concept Suggestion list on footer */}
        {activeChat.length <= 1 && (
          <div id="suggestions-footer" className="p-3 bg-zinc-50 border-t border-zinc-200">
            <span className="text-[10px] font-bold tracking-wider text-zinc-400 block mb-2 px-1 uppercase">SUGGESTED STUDY IDEAS</span>
            <div className="flex flex-wrap gap-1.5 flex-row">
              {selectedPersona.suggestions.map((s, idx) => (
                <button
                  key={idx}
                  id={`suggest-btn-${idx}`}
                  onClick={() => handleSendMessage(s)}
                  className="bg-white hover:bg-zinc-100 border border-zinc-200 text-zinc-700 transition text-[11px] font-medium px-3 py-1.5 rounded-full text-left flex items-center justify-between cursor-pointer"
                >
                  <span className="truncate max-w-[210px] sm:max-w-none">{s}</span>
                  <ChevronRight id={`suggest-chevron-${idx}`} className="w-3.5 h-3.5 text-zinc-400 inline ml-1 flex-shrink-0" />
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Selected files indicator strip */}
        {attachments.length > 0 && (
          <div id="attachments-previews" className="px-4 py-2 border-t border-zinc-200 bg-zinc-50 flex items-center gap-2 overflow-x-auto min-h-[50px]">
            {attachments.map((file, idx) => (
              <div key={idx} className="flex items-center gap-2 p-1 px-2.5 rounded-lg bg-white border border-zinc-200 text-zinc-700 text-[11px] flex-shrink-0 animate-fade-in relative group max-w-[200px]">
                {file.mimeType.startsWith("image/") ? (
                  <img src={`data:${file.mimeType};base64,${file.base64Data}`} className="w-6 h-6 object-cover rounded shadow" />
                ) : (
                  getFileIcon(file.mimeType)
                )}
                <div className="flex flex-col truncate leading-tight">
                  <span className="truncate max-w-[125px] font-medium text-[10px]">{file.name}</span>
                  <span className="text-[8px] text-zinc-450 font-mono">{formatSize(file.size)}</span>
                </div>
                <button 
                  onClick={() => removeAttachment(idx)}
                  className="ml-1.5 text-zinc-400 hover:text-red-500 hover:bg-zinc-100 p-0.5 rounded transition"
                  title="Remove context file"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            ))}
          </div>
        )}

        {/* Message Input Bottom and prompt layout */}
        <div id="chat-control-area" className="p-3.5 border-t border-zinc-200 bg-zinc-50 flex items-center gap-2 relative">
          
          {/* Invisible file input trigger */}
          <input
            ref={fileInputRef}
            type="file"
            multiple
            className="hidden"
            onChange={handleFileChange}
            accept="image/*,video/*,audio/*,application/pdf,text/*"
          />

          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            disabled={isLoading || isTrialExceeded}
            className="p-2.5 rounded-xl bg-white hover:bg-zinc-100 text-zinc-550 hover:text-zinc-800 border border-zinc-200 transition flex items-center justify-center flex-shrink-0 disabled:opacity-50 cursor-pointer animate-fade-in"
            title="Attach visual context (Image, Video, Audio, PDF, Documents)"
          >
            <Paperclip className="w-4 h-4" />
          </button>

          {/* Web Speech Dictation Mic Trigger */}
          <button
            type="button"
            onClick={toggleListening}
            disabled={isLoading || isTrialExceeded}
            className={`p-2.5 rounded-xl transition flex items-center justify-center flex-shrink-0 disabled:opacity-50 border cursor-pointer ${
              isListening 
                ? "bg-red-50 text-red-600 border-red-300 animate-pulse font-semibold" 
                : "bg-white hover:bg-zinc-100 text-zinc-550 hover:text-zinc-800 border-zinc-200"
            }`}
            title={isListening ? "Stop voice dictation" : "Dictate voice question (Web Speech API)"}
          >
            {isListening ? (
              <MicOff className="w-4 h-4 text-red-650 animate-bounce" />
            ) : (
              <Mic className="w-4 h-4" />
            )}
          </button>

          <label htmlFor={inputId} className="sr-only">Message {selectedPersona.name}</label>
          <input
            id={inputId}
            type="text"
            className="flex-1 bg-white border border-zinc-200 focus:border-indigo-505 focus:outline-none focus:ring-1 focus:ring-indigo-500 rounded-xl px-4 py-2.5 text-xs text-zinc-800 placeholder-zinc-400 font-normal shadow-sm disabled:opacity-40"
            placeholder={isTrialExceeded ? "🔒 Session reached basic limit. Activate Premium above!" : `Ask ${selectedPersona.name} or drag & drop files here...`}
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyDown={handleKeyPress}
            disabled={isLoading || isTrialExceeded}
          />
          <button
            id="send-message-btn"
            onClick={() => handleSendMessage(inputValue)}
            disabled={isLoading || isTrialExceeded || (!inputValue.trim() && attachments.length === 0)}
            className="p-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white transition disabled:opacity-30 flex-shrink-0 cursor-pointer"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
