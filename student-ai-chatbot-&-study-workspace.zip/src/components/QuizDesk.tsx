import { useState, useId } from "react";
import { QuizQuestion } from "../types";
import { Sparkles, Trophy, CheckCircle, XCircle, ArrowRight, GraduationCap } from "lucide-react";

export default function QuizDesk() {
  const [concept, setConcept] = useState("");
  const [level, setLevel] = useState("Intermediate");
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [errMsg, setErrMsg] = useState("");

  const [currentIdx, setCurrentIdx] = useState(0);
  const [selectedOpt, setSelectedOpt] = useState<number | null>(null);
  const [isSubmitted, setIsSubmitted] = useState(false);
  
  // Scoring
  const [score, setScore] = useState(0);
  const [showResults, setShowResults] = useState(false);
  
  const questionId = useId();

  const handleGenerateQuiz = async () => {
    if (!concept.trim()) {
      setErrMsg("Please enter a study topic or educational term first.");
      return;
    }
    setErrMsg("");
    setIsLoading(true);
    setQuestions([]);
    setCurrentIdx(0);
    setSelectedOpt(null);
    setIsSubmitted(false);
    setScore(0);
    setShowResults(false);

    try {
      const resp = await fetch("/api/generate-quiz", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ concept, level })
      });

      if (!resp.ok) {
        throw new Error("Unable to contact quiz engine.");
      }

      const data = await resp.json();
      if (!data.quiz || data.quiz.length === 0) {
        throw new Error("Formating issue or empty quiz. Try another concept.");
      }

      setQuestions(data.quiz);
    } catch (e: any) {
      setErrMsg(e.message || "Failed to organize diagnostic quiz.");
    } finally {
      setIsLoading(false);
    }
  };

  const currentQ = questions[currentIdx];

  const handleSelectOption = (index: number) => {
    if (isSubmitted) return;
    setSelectedOpt(index);
  };

  const handleSubmitAnswer = () => {
    if (selectedOpt === null || isSubmitted) return;
    setIsSubmitted(true);

    if (selectedOpt === currentQ.answerIndex) {
      setScore(s => s + 1);
    }
  };

  const handleNextQuestion = () => {
    if (currentIdx + 1 < questions.length) {
      setCurrentIdx(currentIdx + 1);
      setSelectedOpt(null);
      setIsSubmitted(false);
    } else {
      setShowResults(true);
      // Log quiz stats
      try {
        const savedHistory = localStorage.getItem("workspace_quiz_stats");
        let history = [];
        if (savedHistory) {
          try {
            history = JSON.parse(savedHistory);
          } catch (err) {}
        }
        history.push({
          id: Math.random().toString(),
          topic: concept,
          level: level,
          score: score,
          total: questions.length,
          timestamp: new Date().toISOString()
        });
        localStorage.setItem("workspace_quiz_stats", JSON.stringify(history));
      } catch (e) {
        console.error(e);
      }
    }
  };

  const handleResetQuiz = () => {
    setConcept("");
    setQuestions([]);
    setCurrentIdx(0);
    setSelectedOpt(null);
    setIsSubmitted(false);
    setScore(0);
    setShowResults(false);
  };

  return (
    <div id="quiz-root" className="grid grid-cols-1 lg:grid-cols-3 gap-6 font-sans">
      {/* Parameters & Launcher panel */}
      <div id="quiz-sidebar" className="bg-white border border-zinc-205 rounded-xl p-5 flex flex-col gap-4 shadow-sm">
        <div>
          <h3 id="quiz-sidebar-title" className="font-semibold text-zinc-855 text-sm tracking-tight flex items-center gap-1.5 pb-2 border-b border-zinc-200">
            <Sparkles className="h-4 w-4 text-indigo-600" />
            AI Adaptive Quizzing
          </h3>
          <p className="text-[11px] text-zinc-500 mt-1">
            Test your understanding with randomized high-quality analytical diagnostics created directly from your target concepts.
          </p>
        </div>

        <div className="flex flex-col gap-3 mt-1">
          <div className="flex flex-col gap-1">
            <label className="text-[10px] font-bold tracking-wider text-zinc-400 uppercase">QUIZ TOPIC / EXAM CONSOLE</label>
            <input
              type="text"
              placeholder="e.g. Mitosis, Newton's 2nd Law, World War I"
              value={concept}
              onChange={e => setConcept(e.target.value)}
              disabled={isLoading}
              className="bg-white border border-zinc-200 focus:outline-none focus:border-indigo-500 rounded-lg px-3 py-2 text-xs text-zinc-805 placeholder-zinc-400 font-normal shadow-sm"
            />
          </div>

          <div className="flex flex-col gap-1">
            <label className="text-[10px] font-bold tracking-wider text-zinc-500 uppercase">DIFFICULTY LEVEL</label>
            <div className="grid grid-cols-3 gap-1 bg-zinc-100 border border-zinc-200 p-0.5 rounded-lg select-none">
              {["Beginner", "Intermediate", "Advanced"].map(l => (
                <button
                  key={l}
                  type="button"
                  onClick={() => setLevel(l)}
                  className={`py-1.5 rounded-md text-[10px] font-semibold transition cursor-pointer ${
                    level === l 
                      ? "bg-white text-zinc-800 shadow-sm" 
                      : "text-zinc-500 hover:text-zinc-800"
                  }`}
                >
                  {l.toUpperCase()}
                </button>
              ))}
            </div>
          </div>

          <button
            id="make-quiz-btn"
            onClick={handleGenerateQuiz}
            disabled={isLoading || !concept.trim()}
            className="w-full bg-indigo-600 hover:bg-indigo-500 text-white transition rounded-lg py-2.5 text-xs font-bold flex items-center justify-center gap-1.5 disabled:opacity-40 cursor-pointer"
          >
            {isLoading ? "Designing Quiz..." : "Initialize Diagnostic Quiz"}
          </button>
        </div>

        {errMsg && (
          <div className="p-2.5 rounded border border-red-200 bg-red-50 text-[10px] text-red-655 font-semibold">
            {errMsg}
          </div>
        )}
      </div>

      {/* Main Quiz Area */}
      <div id="quiz-board" className="lg:col-span-2">
        {isLoading ? (
          <div id="quiz-loading-stage" className="bg-white border border-zinc-200 rounded-xl h-80 flex flex-col items-center justify-center p-6 text-center text-zinc-550 shadow-sm animate-pulse">
            <GraduationCap className="w-10 h-10 text-indigo-600 animate-bounce mb-2" />
            <h4 className="font-semibold text-zinc-800 text-xs">AI is designing your study evaluator...</h4>
            <p className="text-[11px] leading-relaxed max-w-sm mt-1 text-zinc-450">
              Constructing plausible questions, validating rational answer distractors and compiling immediate explanations...
            </p>
          </div>
        ) : questions.length === 0 ? (
          <div id="quiz-no-stage" className="bg-white border border-zinc-200 rounded-xl h-80 flex flex-col items-center justify-center p-6 text-center text-zinc-450 shadow-sm animate-fade-in">
            <Trophy className="w-10 h-10 text-zinc-400 mb-2" />
            <h4 className="font-semibold text-zinc-700 text-xs">Launch Diagnostic Quiz</h4>
            <p className="text-[11px] leading-relaxed max-w-sm mt-1 text-zinc-500">
              Choose difficulties and type down any concept in the left console to forge an instantaneous 3-question evaluation.
            </p>
          </div>
        ) : showResults ? (
          /* Results Stage */
          <div id="quiz-results" className="bg-white border border-zinc-200 rounded-xl p-6 flex flex-col items-center text-center gap-4 shadow-sm animate-fade-in">
            <div className="relative">
              <div className="w-20 h-20 rounded-full bg-zinc-50 border border-zinc-200 flex items-center justify-center">
                <Trophy className="w-10 h-10 text-indigo-600" />
              </div>
              <div className="absolute -top-1 -right-1 bg-emerald-550 text-white bg-emerald-600 text-[10px] font-bold px-1.5 py-0.5 rounded-full">
                Graded
              </div>
            </div>

            <div>
              <h4 className="font-bold text-zinc-800 text-base">Quiz Completed!</h4>
              <p className="text-[11px] text-zinc-500 mt-1">Topic evaluated: <strong className="font-semibold text-zinc-700 font-bold">"{concept}"</strong></p>
            </div>

            {/* Score box */}
            <div className="bg-zinc-50 border border-zinc-200 rounded-xl px-12 py-3.5 flex flex-col items-center">
              <span className="text-[10px] font-bold tracking-wider text-zinc-400 uppercase">SCORE</span>
              <span className="font-mono text-3xl font-extrabold text-indigo-650 mt-1">
                {score} / {questions.length}
              </span>
              <span className="text-[10px] text-zinc-500 font-semibold mt-1 font-sans">
                {score === questions.length ? "🌟 Perfect logic score!" : score >= 1 ? "👍 Solid work. Review clarifications below!" : "😅 Keep learning, consistency pays!"}
              </span>
            </div>

            <div className="w-full flex justify-center mt-2">
              <button
                id="reset-quiz-btn"
                onClick={handleResetQuiz}
                className="bg-indigo-600 text-white font-bold py-2 px-8 rounded-xl text-xs hover:bg-indigo-505 transition shadow-sm cursor-pointer"
              >
                Tackle Another Quiz
              </button>
            </div>
          </div>
        ) : (
          /* Active Question Carousel Slide */
          <div id="quiz-slider" className="bg-white border border-zinc-200 rounded-xl p-5 flex flex-col gap-4 shadow-sm animate-fade-in">
            {/* Header / progress */}
            <div className="flex items-center justify-between border-b border-zinc-200 pb-2.5">
              <span className="bg-indigo-55 border border-indigo-100 text-indigo-700 font-bold font-mono text-[9px] px-2 py-0.5 rounded uppercase font-extrabold">
                Question {currentIdx + 1} of {questions.length}
              </span>
              <span className="text-[10px] text-zinc-500 font-medium">Subject: <strong className="text-zinc-700 font-semibold capitalize font-bold">"{concept}"</strong></span>
            </div>

            {/* Question Text */}
            <p id={questionId} className="text-[13px] text-zinc-805 font-bold leading-relaxed tracking-tight py-1 font-sans">
              {currentQ.question}
            </p>

            {/* Choices Grid */}
            <div className="flex flex-col gap-2.5">
              {currentQ.options.map((opt, oIdx) => {
                const isSelected = selectedOpt === oIdx;
                const isCorrect = currentQ.answerIndex === oIdx;
                
                let optionStyle = "bg-white border-zinc-205 text-zinc-700 hover:border-indigo-300 hover:bg-indigo-50/10 cursor-pointer";
                
                if (isSubmitted) {
                  if (isCorrect) {
                     optionStyle = "bg-emerald-50 border-emerald-300 text-emerald-800 font-bold";
                  } else if (isSelected) {
                    optionStyle = "bg-rose-50 border-rose-300 text-rose-700 font-semibold";
                  } else {
                    optionStyle = "bg-zinc-50 border-zinc-150 text-zinc-400 opacity-40";
                  }
                } else if (isSelected) {
                  optionStyle = "bg-indigo-50 border-indigo-400 text-indigo-900 font-bold shadow-sm";
                }

                return (
                  <button
                    key={oIdx}
                    id={`quiz-option-${oIdx}`}
                    onClick={() => handleSelectOption(oIdx)}
                    disabled={isSubmitted}
                    className={`w-full text-left p-3.5 rounded-xl border text-xs leading-normal transition-all flex items-start gap-4 ${optionStyle}`}
                  >
                    <span className={`w-5 h-5 rounded-full border flex items-center justify-center font-bold text-[10px] flex-shrink-0 ${
                      isSelected && !isSubmitted ? "bg-indigo-600 text-white border-indigo-650" : "bg-zinc-100 text-zinc-500 border-zinc-200"
                    }`}>
                      {String.fromCharCode(65 + oIdx)}
                    </span>
                    <span className="font-medium text-zinc-750 font-sans leading-relaxed">{opt}</span>
                  </button>
                );
              })}
            </div>

            {/* Diagnostic explanations panel */}
            {isSubmitted && (
              <div id="quiz-feedback-box" className={`p-4 rounded-xl border leading-relaxed ${
                selectedOpt === currentQ.answerIndex ? "bg-emerald-50 border-emerald-250 text-emerald-800" : "bg-zinc-50 border border-zinc-200 text-zinc-700"
              }`}>
                <div className="flex items-center gap-1.5 mb-2">
                  {selectedOpt === currentQ.answerIndex ? (
                    <>
                      <CheckCircle className="w-4 h-4 text-emerald-600" />
                      <span className="text-[11px] font-bold text-emerald-705">Excellent Deduction!</span>
                    </>
                  ) : (
                    <>
                      <XCircle className="w-4 h-4 text-rose-500" />
                      <span className="text-[11px] font-bold text-rose-705">Concept Clarification:</span>
                    </>
                  )}
                </div>
                <p className="text-[11px] font-medium leading-relaxed opacity-95">{currentQ.explanation}</p>
              </div>
            )}

            {/* Nav controls */}
            <div className="flex justify-end gap-2 border-t border-zinc-200 pt-3">
              {!isSubmitted ? (
                <button
                  id="submit-answer-btn"
                  onClick={handleSubmitAnswer}
                  disabled={selectedOpt === null}
                  className="bg-indigo-600 hover:bg-indigo-500 text-white transition py-2 px-6 rounded-lg text-xs font-bold disabled:opacity-40 cursor-pointer shadow"
                >
                  Grade Selection
                </button>
              ) : (
                <button
                  id="next-question-btn"
                  onClick={handleNextQuestion}
                  className="bg-indigo-650 hover:bg-indigo-600 text-white transition py-2 px-5 rounded-lg text-xs font-bold flex items-center gap-1.5 shadow cursor-pointer"
                >
                  {currentIdx + 1 === questions.length ? "Finish Evaluation" : "Next Question"}
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
