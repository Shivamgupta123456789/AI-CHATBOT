import { useState, useEffect, useRef, useId, FormEvent } from "react";
import { StudyTask } from "../types";
import { Sparkles, Timer, Play, Pause, RotateCcw, CheckSquare, Square, Trash2, Bell } from "lucide-react";

export default function StudyPlanTimer() {
  const [goal, setGoal] = useState("");
  const [tasks, setTasks] = useState<StudyTask[]>(() => {
    const saved = localStorage.getItem("workspace_tasks");
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {}
    }
    return [
      { id: "1", text: "Map raw lecture notes regarding cellular structures", completed: false },
      { id: "2", text: "Formulate flashcards on mitochondrial chemical limits", completed: false },
      { id: "3", text: "Answer dynamic quiz questions on ATP conversion", completed: false }
    ];
  });
  
  const [isGenerating, setIsGenerating] = useState(false);
  const [err, setErr] = useState("");
  const [manualTask, setManualTask] = useState("");

  // Timer States
  const [preset, setPreset] = useState<25 | 5 | 15>(25); // Minutes
  const [timeLeft, setTimeLeft] = useState(25 * 60); // Seconds
  const [isRunning, setIsRunning] = useState(false);
  
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const manualInputId = useId();

  // Save tasks list dynamically
  useEffect(() => {
    localStorage.setItem("workspace_tasks", JSON.stringify(tasks));
  }, [tasks]);

  // Handle countdown intervals
  useEffect(() => {
    if (isRunning) {
      timerRef.current = setInterval(() => {
        setTimeLeft(prev => {
          if (prev <= 1) {
            setIsRunning(false);
            triggerPhysicalBell();
            clearInterval(timerRef.current!);

            // Log study session completion
            try {
              const savedHistory = localStorage.getItem("workspace_study_ledger");
              let history = [];
              if (savedHistory) {
                try {
                  history = JSON.parse(savedHistory);
                } catch (err) {}
              }
              history.push({
                id: Math.random().toString(),
                type: "pomodoro",
                topic: `Completed Pomodoro ${preset}m session`,
                duration: preset,
                timestamp: new Date().toISOString()
              });
              localStorage.setItem("workspace_study_ledger", JSON.stringify(history));

              const savedMs = localStorage.getItem("workspace_study_minutes");
              const currentMs = savedMs ? parseInt(savedMs, 10) : 0;
              localStorage.setItem("workspace_study_minutes", (currentMs + preset).toString());
            } catch (e) {
              console.error(e);
            }

            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isRunning, preset]);

  // Adjust remaining seconds when preset shifts
  const handleSetPreset = (minutes: 25 | 5 | 15) => {
    setIsRunning(false);
    setPreset(minutes);
    setTimeLeft(minutes * 60);
  };

  const triggerPhysicalBell = () => {
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();

      osc.type = "sine";
      osc.frequency.setValueAtTime(523.25, audioCtx.currentTime); // C5 note
      gain.gain.setValueAtTime(0.5, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 1.2);

      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + 1.2);
    } catch (e) {
      console.warn("AudioContext block by frame browser flags.");
    }
  };

  const handleGenerateChecklist = async () => {
    if (!goal.trim()) {
      setErr("Goal description cannot be blank.");
      return;
    }
    setErr("");
    setIsGenerating(true);

    try {
      const resp = await fetch("/api/breakdown-tasks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ goal })
      });

      if (!resp.ok) {
        throw new Error("Checker engine error.");
      }

      const data = await resp.json();
      if (!data.tasks || data.tasks.length === 0) {
        throw new Error("No roadmaps fetched. Try adding clarification keywords.");
      }

      const parsed: StudyTask[] = data.tasks.map((t: string) => ({
        id: Math.random().toString(),
        text: t,
        completed: false
      }));

      // Merge or replace
      setTasks(prev => [...parsed, ...prev]);
      setGoal("");
    } catch (error: any) {
      setErr(error.message || "Failed to structure tasks.");
    } finally {
      setIsGenerating(false);
    }
  };

  const handleAddManualTask = (e: FormEvent) => {
    e.preventDefault();
    if (!manualTask.trim()) return;

    const newTask: StudyTask = {
      id: Math.random().toString(),
      text: manualTask.trim(),
      completed: false
    };

    setTasks(prev => [...prev, newTask]);
    setManualTask("");
  };

  const toggleTask = (id: string) => {
    setTasks(prev => prev.map(t => t.id === id ? { ...t, completed: !t.completed } : t));
  };

  const deleteTask = (id: string) => {
    setTasks(prev => prev.filter(t => t.id !== id));
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60).toString().padStart(2, "0");
    const s = (secs % 60).toString().padStart(2, "0");
    return `${m}:${s}`;
  };

  return (
    <div id="plan-timer-root" className="grid grid-cols-1 lg:grid-cols-2 gap-6 font-sans">
      {/* Interactive Goal checklist area */}
      <div id="task-checklist-panel" className="bg-white border border-zinc-200 rounded-xl p-5 flex flex-col gap-4 shadow-sm">
        <div>
          <h3 id="plan-title" className="font-semibold text-zinc-800 text-sm tracking-tight flex items-center gap-1.5 pb-2 border-b border-zinc-200">
            <CheckSquare className="h-4 w-4 text-indigo-600" />
            Study Goals & Session Tasks
          </h3>
          <p className="text-[11px] text-zinc-500 mt-1">
            Create an objective or exam target, let AI plan a sequence of manageable milestones, then cross them out.
          </p>
        </div>

        {/* AI Generator form */}
        <div className="flex items-center gap-2">
          <input
            type="text"
            placeholder="e.g. Master stoichiometry problems, Write essay outline..."
            value={goal}
            onChange={e => setGoal(e.target.value)}
            disabled={isGenerating}
            className="flex-1 bg-white border border-zinc-200 focus:outline-[#f4f4f7] focus:outline-none focus:border-indigo-500 rounded-lg px-3 py-2 text-xs text-zinc-800 placeholder-zinc-400 font-normal shadow-sm"
          />
          <button
            id="goals-builder-btn"
            onClick={handleGenerateChecklist}
            disabled={isGenerating || !goal.trim()}
            className="bg-indigo-600 hover:bg-indigo-500 text-white transition rounded-lg text-xs py-2 px-4 font-bold flex items-center gap-1 flex-shrink-0 disabled:opacity-40 cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5" /> {isGenerating ? "Planning..." : "AI Plan"}
          </button>
        </div>

        {err && (
          <div className="p-2.5 rounded border border-red-200 bg-red-50 text-[10px] text-red-655 font-semibold">
            {err}
          </div>
        )}

        <hr className="border-zinc-200" />

        {/* Task List container */}
        <div className="flex-1 flex flex-col gap-2 max-h-[260px] overflow-y-auto pr-1">
          {tasks.length > 0 ? (
            tasks.map(t => (
              <div 
                key={t.id} 
                id={`task-row-${t.id}`}
                className={`flex items-center justify-between p-3 rounded-lg border transition-all ${
                  t.completed 
                    ? "bg-zinc-50 border-zinc-200 text-zinc-400 font-medium" 
                    : "bg-white border-zinc-200 text-zinc-700 hover:border-zinc-300"
                }`}
              >
                <button
                  id={`toggle-task-btn-${t.id}`}
                  onClick={() => toggleTask(t.id)}
                  className="flex items-center gap-2.5 text-left flex-1 cursor-pointer select-none"
                >
                  {t.completed ? (
                    <CheckSquare className="w-4 h-4 text-indigo-600 flex-shrink-0" />
                  ) : (
                    <Square className="w-4 h-4 text-zinc-300 flex-shrink-0 font-light" />
                  )}
                  <span className={`text-xs font-semibold leading-tight font-sans ${t.completed ? "line-through text-zinc-400" : "text-zinc-800"}`}>
                    {t.text}
                  </span>
                </button>
                <button
                  id={`delete-task-${t.id}`}
                  onClick={() => deleteTask(t.id)}
                  className="p-1 text-zinc-400 hover:text-red-500 rounded transition ml-2 cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))
          ) : (
            <div className="text-center py-6 text-zinc-450 text-[11px] leading-relaxed border border-dashed border-zinc-200 rounded-lg">
              Checklist empty! Type down an overarching goal to get an AI breakdown roadmap.
            </div>
          )}
        </div>

        {/* Quick manuals */}
        <form onSubmit={handleAddManualTask} className="flex gap-1.5 mt-auto bg-zinc-50 p-2 border border-zinc-200 rounded-lg shadow-inner">
          <label htmlFor={manualInputId} className="sr-only">Add sub-step manually</label>
          <input
            id={manualInputId}
            type="text"
            placeholder="Add sub-step manually..."
            value={manualTask}
            onChange={e => setManualTask(e.target.value)}
            className="flex-1 bg-white border border-zinc-200 text-xs px-2.5 py-1.5 rounded focus:outline-none focus:border-indigo-500 text-zinc-800 placeholder-zinc-400"
          />
          <button
            type="submit"
            className="bg-indigo-600 hover:bg-indigo-500 text-white rounded px-3 py-1.5 text-xs font-bold transition cursor-pointer"
          >
            Add
          </button>
        </form>
      </div>

      {/* Focus Timer panel */}
      <div id="countdown-timer-panel" className="bg-white border border-zinc-200 rounded-xl p-5 flex flex-col items-center justify-between text-center min-h-[360px] shadow-sm animate-fade-in">
        {/* Timer Headers */}
        <div className="w-full">
          <h3 id="timer-title" className="font-semibold text-zinc-800 text-sm tracking-tight flex items-center justify-center gap-1.5 pb-2 border-b border-zinc-200">
            <Timer className="h-4 w-4 text-indigo-600" />
            Pomodoro Focus Hub
          </h3>
          <p className="text-[11px] text-zinc-500 mt-1">
            Scientific technique containing deep focus blocks separated by quick breathing breaks.
          </p>
        </div>

        {/* Intervals Preset button selects */}
        <div id="timer-presets" className="flex flex-wrap items-center justify-center gap-1 bg-zinc-100 p-1 rounded-xl border border-zinc-200 select-none mt-2">
          <button
            id="preset-work"
            onClick={() => handleSetPreset(25)}
            className={`px-3 py-1.5 rounded-lg text-[10px] tracking-tight font-bold transition-all cursor-pointer ${
              preset === 25 
                ? "bg-rose-600 text-white shadow-sm" 
                : "text-zinc-500 hover:text-zinc-800"
            }`}
          >
            FOCUS BLOCKS (25m)
          </button>
          <button
            id="preset-break"
            onClick={() => handleSetPreset(5)}
            className={`px-3 py-1.5 rounded-lg text-[10px] tracking-tight font-bold transition-all cursor-pointer ${
              preset === 5 
                ? "bg-emerald-600 text-white shadow-sm" 
                : "text-zinc-500 hover:text-zinc-800"
            }`}
          >
            SHORT BREAK (5m)
          </button>
          <button
            id="preset-long"
            onClick={() => handleSetPreset(15)}
            className={`px-3 py-1.5 rounded-lg text-[10px] tracking-tight font-bold transition-all cursor-pointer ${
              preset === 15 
                ? "bg-indigo-600 text-white shadow-sm" 
                : "text-zinc-500 hover:text-zinc-800"
            }`}
          >
            REST BREAK (15m)
          </button>
        </div>

        {/* Large visual clock display */}
        <div className="my-5 relative">
          {/* Circular border tracking preset flavor values */}
          <div className="w-44 h-44 rounded-full border-4 flex flex-col items-center justify-center bg-zinc-50 border-zinc-200 shadow-sm select-none transition-all duration-500">
            <span className="text-4xl font-extrabold font-mono text-zinc-850 tracking-tight">
              {formatTime(timeLeft)}
            </span>
            <span className="text-[9px] font-extrabold tracking-widest text-zinc-450 block mt-1 uppercase">
              {isRunning ? "Session Active" : "Paused"}
            </span>
          </div>
          {isRunning && (
            <div className="absolute top-2 right-2 flex gap-1 items-center justify-center bg-emerald-50 border border-emerald-250 text-emerald-800 rounded-full py-0.5 px-2 animate-pulse text-[9px] font-bold">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" /> FOCUSING
            </div>
          )}
        </div>

        {/* Live trigger play pause reset controls */}
        <div className="w-full flex justify-center items-center gap-3">
          <button
            id="reset-timer-btn"
            onClick={() => {
              setIsRunning(false);
              setTimeLeft(preset * 60);
            }}
            className="p-3 rounded-full hover:bg-zinc-100 text-zinc-400 hover:text-zinc-700 transition cursor-pointer"
            title="Reset active segment"
          >
            <RotateCcw className="w-4.5 h-4.5" />
          </button>

          <button
            id="play-pause-timer-btn"
            onClick={() => setIsRunning(!isRunning)}
            className={`py-3 px-8 rounded-full font-bold text-xs tracking-wide shadow transition-all duration-150 text-white flex items-center justify-center gap-1.5 cursor-pointer ${
              isRunning ? "bg-zinc-800 hover:bg-zinc-700" : "bg-indigo-600 hover:bg-indigo-505"
            }`}
          >
            {isRunning ? (
              <>
                <Pause className="w-4 h-4" /> Pause Focus
              </>
            ) : (
              <>
                <Play className="w-4 h-4 text-current" /> Begin Focus
              </>
            )}
          </button>

          <button
            id="bell-sound-test-btn"
            onClick={triggerPhysicalBell}
            className="p-3 rounded-full hover:bg-zinc-100 text-zinc-405 hover:text-zinc-700 transition cursor-pointer"
            title="Test interval sound alert"
          >
            <Bell className="w-4.5 h-4.5" />
          </button>
        </div>
      </div>
    </div>
  );
}
