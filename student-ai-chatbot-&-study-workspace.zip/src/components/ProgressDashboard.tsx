import { useState, useEffect, useId, FormEvent } from "react";
import { 
  Trophy, Flame, Clock, BookOpen, Layers, CheckSquare, Sparkles, 
  Plus, Trash2, Calendar, TrendingUp, BarChart3, Check, RefreshCw 
} from "lucide-react";
import { Flashcard, StudyTask, ChatSession } from "../types";

interface StudyLog {
  id: string;
  type: "pomodoro" | "manual";
  topic: string;
  duration: number; // in mins
  timestamp: string;
}

interface QuizLog {
  id: string;
  topic: string;
  level: string;
  score: number;
  total: number;
  timestamp: string;
}

interface ExplainerLog {
  id: string;
  concept: string;
  mode: string;
  timestamp: string;
}

export default function ProgressDashboard() {
  const [studyMinutes, setStudyMinutes] = useState(0);
  const [studyLedger, setStudyLedger] = useState<StudyLog[]>([]);
  const [quizLogs, setQuizLogs] = useState<QuizLog[]>([]);
  const [explainerLogs, setExplainerLogs] = useState<ExplainerLog[]>([]);
  
  // Cross-component values loaded on mount
  const [flashcardCount, setFlashcardCount] = useState(0);
  const [tasksCount, setTasksCount] = useState({ total: 0, completed: 0 });
  const [chatCount, setChatCount] = useState({ sessions: 0, messages: 0 });

  // Custom log inputs
  const [logTopic, setLogTopic] = useState("");
  const [logDuration, setLogDuration] = useState(30);
  const [logSubject, setLogSubject] = useState("STEM");
  const [dailyGoal, setDailyGoal] = useState(() => {
    const saved = localStorage.getItem("workspace_daily_goal");
    return saved ? parseInt(saved, 10) : 45; // default 45 minutes
  });

  const durationInputId = useId();
  const topicInputId = useId();
  const goalInputId = useId();

  // Load all stats from localStorage
  const loadStats = () => {
    // 1. Study Minutes
    const minutes = localStorage.getItem("workspace_study_minutes");
    setStudyMinutes(minutes ? parseInt(minutes, 10) : 0);

    // 2. Study Ledger list
    const ledgerSaved = localStorage.getItem("workspace_study_ledger");
    if (ledgerSaved) {
      try {
        setStudyLedger(JSON.parse(ledgerSaved));
      } catch (e) {}
    } else {
      setStudyLedger([]);
    }

    // 3. Quiz Log list
    const quizSaved = localStorage.getItem("workspace_quiz_stats");
    if (quizSaved) {
      try {
        setQuizLogs(JSON.parse(quizSaved));
      } catch (e) {}
    } else {
      setQuizLogs([]);
    }

    // 4. Summaries Explained list
    const explainSaved = localStorage.getItem("workspace_explain_stats");
    if (explainSaved) {
      try {
        setExplainerLogs(JSON.parse(explainSaved));
      } catch (e) {}
    } else {
      setExplainerLogs([]);
    }

    // 5. Flashcards Count
    const fcSaved = localStorage.getItem("workspace_flashcards");
    if (fcSaved) {
      try {
        const fc: Flashcard[] = JSON.parse(fcSaved);
        setFlashcardCount(fc.length);
      } catch (e) {}
    } else {
      setFlashcardCount(3); // starter cards fallback
    }

    // 6. Tasks Goals checklist check
    const tasksSaved = localStorage.getItem("workspace_tasks");
    if (tasksSaved) {
      try {
        const t: StudyTask[] = JSON.parse(tasksSaved);
        const completed = t.filter(x => x.completed).length;
        setTasksCount({ total: t.length, completed });
      } catch (e) {}
    } else {
      setTasksCount({ total: 3, completed: 0 });
    }

    // 7. Chats and Message metrics
    const chatsSaved = localStorage.getItem("workspace_chat_sessions");
    if (chatsSaved) {
      try {
        const chatSess: ChatSession[] = JSON.parse(chatsSaved);
        let msgTotals = 0;
        chatSess.forEach(s => {
          msgTotals += s.messages.length;
        });
        setChatCount({ sessions: chatSess.length, messages: msgTotals });
      } catch (e) {}
    } else {
      setChatCount({ sessions: 4, messages: 4 });
    }
  };

  useEffect(() => {
    loadStats();
    // Listen for storage changes in other tabs
    window.addEventListener("storage", loadStats);
    return () => {
      window.removeEventListener("storage", loadStats);
    };
  }, []);

  // Sync daily study limit goals
  useEffect(() => {
    localStorage.setItem("workspace_daily_goal", dailyGoal.toString());
  }, [dailyGoal]);

  // Handle Manual Log Submission
  const handleLogManual = (e: FormEvent) => {
    e.preventDefault();
    if (!logTopic.trim()) return;

    const newLog: StudyLog = {
      id: Math.random().toString(),
      type: "manual",
      topic: `${logSubject}: ${logTopic.trim()}`,
      duration: logDuration,
      timestamp: new Date().toISOString()
    };

    const updatedLedger = [newLog, ...studyLedger];
    setStudyLedger(updatedLedger);
    localStorage.setItem("workspace_study_ledger", JSON.stringify(updatedLedger));

    const newTotalMinutes = studyMinutes + logDuration;
    setStudyMinutes(newTotalMinutes);
    localStorage.setItem("workspace_study_minutes", newTotalMinutes.toString());

    // Reset fields
    setLogTopic("");
  };

  // Seed sample interactive data so that the user doesn't start with a blank screen
  const handleSeedData = () => {
    if (confirm("Would you like to seed simulated high-fidelity study and quiz sessions to preview the visual charts?")) {
      const simulatedStudyLedger: StudyLog[] = [
        { id: "s1", type: "pomodoro", topic: "Completed Pomodoro 25m session", duration: 25, timestamp: new Date(Date.now() - 3600000 * 2).toISOString() },
        { id: "s2", type: "manual", topic: "STEM: Photosynthesis chapter prep", duration: 45, timestamp: new Date(Date.now() - 3600000 * 15).toISOString() },
        { id: "s3", type: "pomodoro", topic: "Completed Pomodoro 25m session", duration: 25, timestamp: new Date(Date.now() - 3600000 * 24).toISOString() },
        { id: "s4", type: "manual", topic: "Coding: React state debugging review", duration: 60, timestamp: new Date(Date.now() - 3600000 * 48).toISOString() },
        { id: "s5", type: "pomodoro", topic: "Completed Pomodoro 15m session", duration: 15, timestamp: new Date(Date.now() - 3600000 * 72).toISOString() },
        { id: "s6", type: "manual", topic: "Humanities: Metaphor analysis outlines", duration: 30, timestamp: new Date(Date.now() - 3600000 * 96).toISOString() }
      ];

      const simulatedQuizzes: QuizLog[] = [
        { id: "q1", topic: "Cellular Cellular Respiration", level: "Intermediate", score: 3, total: 3, timestamp: new Date(Date.now() - 3600000 * 4).toISOString() },
        { id: "q2", topic: "Newtonian Physics Limits", level: "Advanced", score: 2, total: 3, timestamp: new Date(Date.now() - 3600000 * 30).toISOString() },
        { id: "q3", topic: "Literary Devices & Metaphors", level: "Beginner", score: 3, total: 3, timestamp: new Date(Date.now() - 3600000 * 80).toISOString() }
      ];

      const simulatedExplanations: ExplainerLog[] = [
        { id: "e1", concept: "Krebs Citric Acid Cycle ATP yield details", mode: "summary", timestamp: new Date(Date.now() - 3600000 * 5).toISOString() },
        { id: "e2", concept: "Schrödinger Wave Equation mechanics", mode: "eli5", timestamp: new Date(Date.now() - 3600000 * 34).toISOString() }
      ];

      localStorage.setItem("workspace_study_ledger", JSON.stringify(simulatedStudyLedger));
      localStorage.setItem("workspace_quiz_stats", JSON.stringify(simulatedQuizzes));
      localStorage.setItem("workspace_explain_stats", JSON.stringify(simulatedExplanations));
      localStorage.setItem("workspace_study_minutes", "200");

      loadStats();
    }
  };

  // Clear all statistics
  const handleClearData = () => {
    if (confirm("Are you sure you want to permanently delete all study logs, focus time ledger and quiz achievements in this workspace? This will reset all charts.")) {
      localStorage.removeItem("workspace_study_ledger");
      localStorage.removeItem("workspace_quiz_stats");
      localStorage.removeItem("workspace_explain_stats");
      localStorage.setItem("workspace_study_minutes", "0");
      
      loadStats();
    }
  };

  // Compute Weekly study data (Mon-Sun total minutes for the SVG chart)
  const getWeeklyMinutes = () => {
    const dailyTotals: { [key: number]: number } = { 0: 0, 1: 0, 2: 0, 3: 0, 4: 0, 5: 0, 6: 0 }; // 0: Sunday, 1: Monday etc
    
    // Total from ledger
    studyLedger.forEach(log => {
      const date = new Date(log.timestamp);
      const day = date.getDay(); // 0 - 6
      dailyTotals[day] += log.duration;
    });

    return [
      { name: "Mon", key: 1, mins: dailyTotals[1] },
      { name: "Tue", key: 2, mins: dailyTotals[2] },
      { name: "Wed", key: 3, mins: dailyTotals[3] },
      { name: "Thu", key: 4, mins: dailyTotals[4] },
      { name: "Fri", key: 5, mins: dailyTotals[5] },
      { name: "Sat", key: 6, mins: dailyTotals[6] },
      { name: "Sun", key: 0, mins: dailyTotals[0] }
    ];
  };

  const chartData = getWeeklyMinutes();
  const maxMinutes = Math.max(...chartData.map(d => d.mins), 60); // normalization scale
  
  // Assemble combined timelines of milestones
  const getCombinedMilestones = () => {
    const milestones: {
      id: string;
      type: "study" | "quiz" | "explain";
      title: string;
      subtitle: string;
      detail: string;
      timestamp: Date;
    }[] = [];

    studyLedger.forEach(item => {
      milestones.push({
        id: item.id,
        type: "study",
        title: item.type === "pomodoro" ? "Pomodoro session completed" : "Manual Log logged",
        subtitle: `${item.duration} minutes studied`,
        detail: item.topic,
        timestamp: new Date(item.timestamp)
      });
    });

    quizLogs.forEach(quiz => {
      milestones.push({
        id: quiz.id,
        type: "quiz",
        title: `Finished Diagnostic Quiz`,
        subtitle: `Score: ${quiz.score}/${quiz.total} (${quiz.level})`,
        detail: `Evaluated topic: "${quiz.topic}"`,
        timestamp: new Date(quiz.timestamp)
      });
    });

    explainerLogs.forEach(expl => {
      milestones.push({
        id: expl.id,
        type: "explain",
        title: `Concept Simplified & Explained`,
        subtitle: `Mode: ${expl.mode.toUpperCase()}`,
        detail: `Material: ${expl.concept}`,
        timestamp: new Date(expl.timestamp)
      });
    });

    // Sort chronologically (most recent first)
    return milestones.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime()).slice(0, 10);
  };

  const recentMilestones = getCombinedMilestones();

  // Compute stats helper
  const totalQuizAnswers = quizLogs.reduce((acc, curr) => acc + curr.score, 0);
  const totalQuizQuestions = quizLogs.reduce((acc, curr) => acc + curr.total, 0);
  const quizAccuracyPercent = totalQuizQuestions > 0 ? Math.round((totalQuizAnswers / totalQuizQuestions) * 100) : 0;
  
  // Daily Goal percent
  const goalPercent = Math.min(Math.round((studyMinutes / dailyGoal) * 100), 100);

  return (    <div id="progress-dashboard-root" className="flex flex-col gap-6 animate-fade-in text-zinc-800 font-sans">
      
      {/* Top Welcome Title Banner */}
      <div className="bg-white border border-zinc-200 rounded-xl p-5 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-sm">
        <div>
          <h2 id="dashboard-heading" className="text-base font-bold text-zinc-850 tracking-tight flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-indigo-600" />
            Study Workspace Progress Center
          </h2>
          <p className="text-[11px] text-zinc-500 mt-1 max-w-xl">
            Visualize your study cycles, track performance metrics, verify task milestones, and record external learning activities in a single unified dashboard.
          </p>
        </div>

        {/* Action Triggers */}
        <div className="flex items-center gap-2 self-start md:self-auto flex-shrink-0">
          <button
            id="seed-samples-btn"
            onClick={handleSeedData}
            className="bg-zinc-50 border border-zinc-200 hover:border-indigo-300 hover:text-indigo-650 hover:bg-indigo-50/20 px-3.5 py-1.5 rounded-lg text-xs font-bold text-zinc-650 transition flex items-center gap-1 cursor-pointer shadow-sm"
            title="Populate test data to check charts"
          >
            <Sparkles className="w-3.5 h-3.5 text-indigo-500 animate-pulse" />
            Seed Sample Data
          </button>
          
          <button
            id="reset-stats-btn"
            onClick={handleClearData}
            className="bg-zinc-50 border border-zinc-200 hover:border-red-300 hover:text-red-650 hover:bg-red-50 px-3.5 py-1.5 rounded-lg text-xs font-bold text-zinc-500 transition flex items-center gap-1 cursor-pointer shadow-sm"
            title="Reset storage logs"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            Reset Data
          </button>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        
        {/* KPI 1: Study Minutes */}
        <div className="bg-white border border-zinc-200 rounded-xl p-4 flex flex-col justify-between shadow-sm">
          <div className="flex items-center justify-between text-zinc-400">
            <span className="text-[9px] font-extrabold tracking-wider uppercase font-mono">Study Time</span>
            <Clock className="w-4 h-4 text-indigo-600" />
          </div>
          <div className="mt-3">
            <h3 className="text-2xl font-extrabold text-zinc-800 tracking-tight">
              {studyMinutes} <span className="text-xs font-normal text-zinc-500">mins</span>
            </h3>
            <p className="text-[10px] text-zinc-500 mt-1 font-medium">
              {Math.round((studyMinutes / 60) * 10) / 10} hours of active focus
            </p>
          </div>
        </div>

        {/* KPI 2: Quiz Accuracy */}
        <div className="bg-white border border-zinc-200 rounded-xl p-4 flex flex-col justify-between shadow-sm">
          <div className="flex items-center justify-between text-zinc-400">
            <span className="text-[9px] font-extrabold tracking-wider uppercase font-mono">Quiz Score</span>
            <Trophy className="w-4 h-4 text-amber-500" />
          </div>
          <div className="mt-3">
            <h3 className="text-2xl font-extrabold text-zinc-800 tracking-tight">
              {quizAccuracyPercent}% <span className="text-xs font-normal text-zinc-500">avg</span>
            </h3>
            <p className="text-[10px] text-zinc-500 mt-1 font-medium">
              Completed {quizLogs.length} diagnostic quizzes
            </p>
          </div>
        </div>

        {/* KPI 3: Flashcard Metrics */}
        <div className="bg-white border border-zinc-200 rounded-xl p-4 flex flex-col justify-between shadow-sm">
          <div className="flex items-center justify-between text-zinc-400">
            <span className="text-[9px] font-extrabold tracking-wider uppercase font-mono">Active Cards</span>
            <Layers className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="mt-3">
            <h3 className="text-2xl font-extrabold text-zinc-800 tracking-tight">
              {flashcardCount} <span className="text-xs font-normal text-zinc-500">items</span>
            </h3>
            <p className="text-[10px] text-zinc-500 mt-1 font-medium">
              Spaced revision materials built
            </p>
          </div>
        </div>

        {/* KPI 4: Goals Completed */}
        <div className="bg-white border border-zinc-200 rounded-xl p-4 flex flex-col justify-between shadow-sm">
          <div className="flex items-center justify-between text-zinc-400">
            <span className="text-[9px] font-extrabold tracking-wider uppercase font-mono">Goal Progress</span>
            <CheckSquare className="w-4 h-4 text-indigo-600" />
          </div>
          <div className="mt-3">
            <h3 className="text-2xl font-extrabold text-zinc-800 tracking-tight">
              {tasksCount.completed}/{tasksCount.total} <span className="text-xs font-normal text-zinc-500">done</span>
            </h3>
            <p className="text-[10px] text-zinc-500 mt-1 font-medium">
              {tasksCount.total > 0 ? Math.round((tasksCount.completed / tasksCount.total) * 100) : 0}% checklist completed
            </p>
          </div>
        </div>

        {/* KPI 5: Chat Threads */}
        <div className="bg-white border border-zinc-200 rounded-xl p-4 col-span-2 lg:col-span-1 flex flex-col justify-between shadow-sm">
          <div className="flex items-center justify-between text-zinc-400">
            <span className="text-[9px] font-extrabold tracking-wider uppercase font-mono">AI Mentorship</span>
            <BookOpen className="w-4 h-4 text-sky-600" />
          </div>
          <div className="mt-3">
            <h3 className="text-2xl font-extrabold text-zinc-800 tracking-tight">
              {chatCount.messages} <span className="text-xs font-normal text-zinc-500">msgs</span>
            </h3>
            <p className="text-[10px] text-zinc-500 mt-1 font-medium">
              Across {chatCount.sessions} study topics
            </p>
          </div>
        </div>

      </div>

      {/* Main Analysis and Manual Logs grid layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Double-wide column: Chart & Logs Builder */}
        <div className="lg:col-span-2 flex flex-col gap-6">
          
          {/* Weekly SVG Bar Chart Block */}
          <div className="bg-white border border-zinc-200 rounded-xl p-5 flex flex-col gap-4 shadow-sm">
            <div className="flex items-center justify-between border-b border-zinc-200 pb-3">
              <h3 className="font-semibold text-zinc-850 text-xs tracking-tight flex items-center gap-1.5">
                <BarChart3 className="h-4 w-4 text-indigo-600" />
                Study Time Distribution (Weekly Trend)
              </h3>
              <span className="text-[10px] font-bold text-indigo-700 uppercase font-mono tracking-widest bg-indigo-50 p-1 px-2 border border-indigo-150 rounded">
                Logged Active Minutes
              </span>
            </div>

            {/* Render the SVG manual Bar Chart */}
            <div className="h-56 w-full flex items-end justify-between px-4 pt-4 pb-2 border border-zinc-150 bg-zinc-50/50 rounded-xl select-none">
              {chartData.map((day) => {
                const barHeightPercent = Math.max((day.mins / maxMinutes) * 100, 4); // minimum 4% indicating baseline
                const isToday = new Date().getDay() === day.key;

                return (
                  <div key={day.name} className="flex-1 flex flex-col items-center gap-2 h-full justify-end group">
                    {/* Tooltip on hovering a bar */}
                    <div className="hidden group-hover:block absolute bg-zinc-800 border border-zinc-700 px-2 py-1.5 rounded text-[10px] text-white mt-2 font-mono shadow-md z-40 transform -translate-y-24">
                      <strong>{day.mins} minutes</strong>
                    </div>

                    {/* Interactive Animated Bar Column */}
                    <div className="w-7 sm:w-10 rounded-t-md relative overflow-hidden transition-all duration-300 bg-zinc-200 border border-zinc-300 flex items-end justify-center group-hover:border-zinc-400" style={{ height: `${barHeightPercent}%` }}>
                      <div className={`w-full ${isToday ? "bg-indigo-650" : "bg-gradient-to-t from-zinc-200 to-indigo-500"} transition-all`} style={{ height: "100%" }} />
                    </div>

                    {/* Week Label */}
                    <span className={`text-[10px] font-semibold tracking-tight ${isToday ? "text-indigo-600 font-extrabold" : "text-zinc-450"}`}>
                      {day.name}
                    </span>
                  </div>
                );
              })}
            </div>

            {/* Quick Chart Meta info summary */}
            <div className="grid grid-cols-2 gap-4 bg-zinc-50/50 p-3 rounded-lg border border-zinc-200 text-xs">
              <div>
                <span className="text-[9px] text-zinc-400 font-extrabold block uppercase tracking-wide">Weekly Cumulative</span>
                <p className="text-zinc-700 font-bold mt-0.5">
                  {chartData.reduce((acc, curr) => acc + curr.mins, 0)} Active Minutes Logged
                </p>
              </div>
              <div className="border-l border-zinc-200 pl-4">
                <span className="text-[9px] text-zinc-400 font-extrabold block uppercase tracking-wide font-sans">Most Studious Day</span>
                <p className="text-indigo-600 font-bold mt-0.5">
                  {chartData.reduce((max, curr) => curr.mins > max.mins ? curr : max, chartData[0]).name}
                  {chartData.some(d => d.mins > 0) ? ` (${Math.max(...chartData.map(d => d.mins))}m)` : " (No activities logged)"}
                </p>
              </div>
            </div>

          </div>

          {/* Log Custom study session entry component */}
          <div className="bg-white border border-zinc-200 rounded-xl p-5 flex flex-col gap-4 shadow-sm">
            <div>
              <h3 className="font-semibold text-zinc-850 text-xs tracking-tight flex items-center gap-1.5 pb-2 border-b border-zinc-200">
                <Plus className="h-4 w-4 text-emerald-600" />
                Log Off-Screen Study Session
              </h3>
              <p className="text-[11px] text-zinc-500 mt-1 font-medium">
                Spent time reading physical textbooks, attending lectures, or preparing homework offline? Add it to your overall workload distribution ledger!
              </p>
            </div>

            <form onSubmit={handleLogManual} className="grid grid-cols-1 md:grid-cols-4 gap-3">
              <div className="md:col-span-2 flex flex-col gap-1">
                <label htmlFor={topicInputId} className="text-[9px] font-extrabold text-zinc-500 uppercase tracking-widest">Topic or Module</label>
                <input
                  id={topicInputId}
                  type="text"
                  placeholder="e.g. Bio chapter 4 exam prep, Physics equations..."
                  value={logTopic}
                  onChange={e => setLogTopic(e.target.value)}
                  required
                  className="bg-white border border-zinc-200 focus:outline-[#f4f4f7] focus:outline-none focus:border-indigo-500 rounded-lg px-3 py-2 text-xs text-zinc-800 placeholder-zinc-400 shadow-sm"
                />
              </div>

              <div className="flex flex-col gap-1">
                <label htmlFor={durationInputId} className="text-[9px] font-extrabold text-zinc-500 uppercase tracking-widest">Duration (min)</label>
                <input
                  id={durationInputId}
                  type="number"
                  min="5"
                  max="480"
                  value={logDuration}
                  onChange={e => setLogDuration(parseInt(e.target.value, 10) || 5)}
                  required
                  className="bg-white border border-zinc-200 focus:outline-[#f4f4f7] focus:outline-none focus:border-indigo-500 rounded-lg px-3 py-2 text-xs text-zinc-800 placeholder-zinc-400 shadow-sm"
                />
              </div>

              <div className="flex flex-col gap-1">
                <label className="text-[9px] font-extrabold text-zinc-500 uppercase tracking-widest">Subject Group</label>
                <select
                  value={logSubject}
                  onChange={e => setLogSubject(e.target.value)}
                  className="bg-white border border-zinc-200 focus:outline-[#f4f4f7] focus:outline-none focus:border-indigo-500 rounded-lg px-3 py-2 text-xs text-zinc-800 select-dropdown shadow-sm"
                >
                  <option value="STEM">STEM (Math/Sci)</option>
                  <option value="Humanities">Humanities/Arts</option>
                  <option value="Coding">Software Engine</option>
                  <option value="Lang">Languages</option>
                  <option value="Gen">General Revision</option>
                </select>
              </div>

              <div className="md:col-span-4 flex justify-end mt-1">
                <button
                  type="submit"
                  disabled={!logTopic.trim()}
                  className="bg-indigo-650 hover:bg-indigo-600 text-white font-bold text-xs px-5 py-2.5 rounded-lg transition-all flex items-center gap-1.5 disabled:opacity-40 cursor-pointer shadow-sm"
                >
                  <Plus className="w-3.5 h-3.5" />
                  Commit to Ledger
                </button>
              </div>
            </form>
          </div>

        </div>

        {/* Right column: Target Goals Tracker & Activity Ledger Timeline */}        <div className="flex flex-col gap-6">
          
          {/* Goal tracker ring component */}
          <div className="bg-white border border-zinc-200 rounded-xl p-5 flex flex-col gap-4 shadow-sm">
            <h3 className="font-semibold text-zinc-850 text-xs tracking-tight flex items-center gap-1.5 pb-2 border-b border-zinc-200">
              <Flame className="h-4 w-4 text-orange-500 animate-pulse" />
              Daily Focus Target
            </h3>

            {/* Circular Ring Progress or linear gauge */}
            <div className="flex flex-col items-center justify-center p-2 text-center">
              <div className="relative w-32 h-32 flex items-center justify-center">
                
                {/* Visual SVG Ring */}
                <svg className="w-full h-full transform -rotate-90">
                  <circle
                    cx="64"
                    cy="64"
                    r="52"
                    stroke="#eaeaea"
                    strokeWidth="8"
                    fill="transparent"
                  />
                  <circle
                    cx="64"
                    cy="64"
                    r="52"
                    stroke="#4f46e5"
                    strokeWidth="8"
                    fill="transparent"
                    strokeDasharray={326.7}
                    strokeDashoffset={326.7 - (326.7 * goalPercent) / 100}
                    className="transition-all duration-700 ease-out"
                    strokeLinecap="round"
                  />
                </svg>

                <div className="absolute text-center flex flex-col">
                  <span className="text-xl font-extrabold text-zinc-800 font-mono">{goalPercent}%</span>
                  <span className="text-[8px] font-bold text-zinc-400 uppercase tracking-wide">Completed</span>
                </div>
              </div>

              <div className="mt-4">
                <h4 className="text-xs font-bold text-zinc-700">
                  {studyMinutes} / {dailyGoal} Minutes Focused
                </h4>
                <p className="text-[10px] text-zinc-500 mt-1 font-medium">
                  {studyMinutes >= dailyGoal ? "🌟 Daily study targets fully met! Superb consistency!" : "Keep committing learning blocks to hit target."}
                </p>
              </div>
            </div>

            {/* Configurable target minutes */}
            <div className="bg-zinc-50 border border-zinc-200 p-2 text-xs rounded-lg flex items-center justify-between">
              <label htmlFor={goalInputId} className="text-zinc-500 font-bold">Daily Target Limit:</label>
              <select
                id={goalInputId}
                value={dailyGoal}
                onChange={e => setDailyGoal(parseInt(e.target.value, 10))}
                className="bg-white border border-zinc-200 text-zinc-750 text-[11px] rounded p-1 px-1.5 focus:outline-none focus:border-indigo-500 font-semibold"
              >
                <option value="15">15 Min (Chill)</option>
                <option value="30">30 Min (Active)</option>
                <option value="45">45 Min (Normal)</option>
                <option value="60">60 Min (Disciplined)</option>
                <option value="120">120 Min (Deep Intensive)</option>
              </select>
            </div>
          </div>

          {/* Unified Recent Milestones timeline stream */}
          <div className="bg-white border border-zinc-200 rounded-xl p-5 flex flex-col flex-1 max-h-[460px] overflow-hidden shadow-sm">
            <h3 className="font-semibold text-zinc-850 text-xs tracking-tight flex items-center gap-1.5 pb-2.5 border-b border-zinc-200">
              <Calendar className="h-4 w-4 text-sky-600" />
              Activity Ledger Timeline
            </h3>

            <div className="flex-1 overflow-y-auto mt-4 pr-1 flex flex-col gap-4 font-sans text-xs">
              {recentMilestones.length > 0 ? (
                recentMilestones.map((item) => (
                  <div key={item.id} className="relative pl-5 border-l-2 border-zinc-100 last:border-transparent">
                    {/* Circle icon */}
                    <div className="absolute -left-[5px] top-[3px] w-2 h-2 rounded-full bg-indigo-600 border border-indigo-555" />

                    <div className="flex flex-col animate-fade-in">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-zinc-800 text-[11px]">
                          {item.title}
                        </span>
                        <span className="text-[9px] text-zinc-455 font-mono">
                          {item.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                      
                      <span className="text-indigo-605 font-bold text-[10px] mt-0.5">
                        {item.subtitle}
                      </span>
                      
                      <p className="text-[10px] text-zinc-500 mt-1 leading-normal not-italic text-wrap break-words font-medium">
                        {item.detail}
                      </p>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-16 text-zinc-400 italic text-[11px] border border-dashed border-zinc-200 rounded-xl my-4">
                  Timeline empty! Finish active quizzes, complete Pomodoro timers, simplify textbook contents or log manual lessons to populate your milestone stream!
                </div>
              )}
            </div>
          </div>
        </div>

      </div>

    </div>
  );
}
