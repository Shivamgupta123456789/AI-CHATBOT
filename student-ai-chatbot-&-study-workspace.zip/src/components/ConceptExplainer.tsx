import { useState } from "react";
import { Sparkles, HelpCircle, FileText, Code2, Layers, BookOpen, Quote } from "lucide-react";

export default function ConceptExplainer() {
  const [inputText, setInputText] = useState("");
  const [mode, setMode] = useState<"summary" | "eli5" | "formulas" | "detailed">("summary");
  const [explanation, setExplanation] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [errorText, setErrorText] = useState("");

  const handleSimplify = async () => {
    if (!inputText.trim()) {
      setErrorText("Please paste textbook notes, articles, or transcripts first.");
      return;
    }
    setErrorText("");
    setIsLoading(true);
    setExplanation("");

    try {
      const resp = await fetch("/api/explain-concept", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: inputText, mode })
      });

      if (!resp.ok) {
        throw new Error("Simplify engine did not respond.");
      }

      const data = await resp.json();
      setExplanation(data.explanation || "No explanation returned. Adjust material text.");
      
      if (data.explanation) {
        try {
          const savedHistory = localStorage.getItem("workspace_explain_stats");
          let history = [];
          if (savedHistory) {
            try {
              history = JSON.parse(savedHistory);
            } catch (err) {}
          }
          history.push({
            id: Math.random().toString(),
            concept: inputText.trim().substring(0, 50) + (inputText.length > 50 ? "..." : ""),
            mode,
            timestamp: new Date().toISOString()
          });
          localStorage.setItem("workspace_explain_stats", JSON.stringify(history));
        } catch (e) {
          console.error(e);
        }
      }
    } catch (e: any) {
      setErrorText(e.message || "Failed to process text.");
    } finally {
      setIsLoading(false);
    }
  };

  const getModeTitle = () => {
    switch (mode) {
      case "eli5": return "Explain like I'm 5 (ELI5) / Simple Metaphors";
      case "formulas": return "Core Mathematical & Scientific Laws (Extracted)";
      case "detailed": return "Detailed Academic Sub-principles";
      default: return "Concise Takeaways & Structural Summaries";
    }
  };

  return (
    <div id="explainer-root" className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Left Input Board */}
      <div id="explainer-left" className="bg-white border border-zinc-200 rounded-xl p-5 flex flex-col gap-4 shadow-sm">
        <div>
          <h3 id="explainer-title" className="font-semibold text-zinc-805 text-sm tracking-tight flex items-center gap-1.5">
            <BookOpen className="h-4 w-4 text-indigo-605" />
            Concept Explainer & Summarizer
          </h3>
          <p className="text-[11px] text-zinc-500 mt-1">
            Convert complicated lectures, jargon-filled articles, or raw notes into digestible explanations designed to accelerate your study cycle.
          </p>
        </div>

        <div className="flex flex-col gap-1.5 flex-1 min-h-[160px]">
          <label className="text-[10px] font-bold tracking-wider text-zinc-400 uppercase">PASTE RAW STUDY MATERIAL</label>
          <textarea
            className="flex-1 w-full bg-white border border-zinc-200 focus:outline-none focus:border-indigo-500 rounded-lg p-3 text-xs text-zinc-800 placeholder-zinc-400 font-normal resize-none leading-relaxed shadow-sm animate-fade-in"
            placeholder="Paste raw text (paragraphs, math statements, lecture transcripts...) here..."
            value={inputText}
            onChange={e => setInputText(e.target.value)}
            disabled={isLoading}
          />
        </div>

        <div className="flex flex-col gap-2 bg-zinc-50 p-3 rounded-lg border border-zinc-200">
          <label className="text-[10px] font-bold tracking-wider text-zinc-500 uppercase">SELECT SIMPLIFIER FOCUS</label>
          <div className="grid grid-cols-2 gap-2">
            <button
              id="mode-summary"
              onClick={() => setMode("summary")}
              className={`p-2.5 rounded-lg border text-left transition select-none cursor-pointer ${
                mode === "summary" 
                  ? "bg-indigo-600 border-indigo-500 text-white shadow-sm font-semibold" 
                  : "bg-white border-zinc-200 text-zinc-600 hover:border-zinc-300 hover:text-zinc-800"
              }`}
            >
              <div className="flex items-center gap-1.5">
                <FileText className="w-3.5 h-3.5" />
                <span className="text-[11px]">Core Takeaways</span>
              </div>
            </button>

            <button
              id="mode-eli5"
              onClick={() => setMode("eli5")}
              className={`p-2.5 rounded-lg border text-left transition select-none cursor-pointer ${
                mode === "eli5" 
                  ? "bg-indigo-600 border-indigo-500 text-white shadow-sm font-semibold" 
                  : "bg-white border-zinc-200 text-zinc-600 hover:border-zinc-300 hover:text-zinc-800"
              }`}
            >
              <div className="flex items-center gap-1.5">
                <HelpCircle className="w-3.5 h-3.5" />
                <span className="text-[11px]">Explain like I'm 5</span>
              </div>
            </button>

            <button
              id="mode-formulas"
              onClick={() => setMode("formulas")}
              className={`p-2.5 rounded-lg border text-left transition select-none cursor-pointer ${
                mode === "formulas" 
                  ? "bg-indigo-600 border-indigo-500 text-white shadow-sm font-semibold" 
                  : "bg-white border-zinc-200 text-zinc-600 hover:border-zinc-300 hover:text-zinc-800"
              }`}
            >
              <div className="flex items-center gap-1.5">
                <Code2 className="w-3.5 h-3.5" />
                <span className="text-[11px]">Extract Formulas</span>
              </div>
            </button>

            <button
              id="mode-detailed"
              onClick={() => setMode("detailed")}
              className={`p-2.5 rounded-lg border text-left transition select-none cursor-pointer ${
                mode === "detailed" 
                  ? "bg-indigo-600 border-indigo-500 text-white shadow-sm font-semibold" 
                  : "bg-white border-zinc-200 text-zinc-600 hover:border-zinc-300 hover:text-zinc-800"
              }`}
            >
              <div className="flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5" />
                <span className="text-[11px]">Deep Academic</span>
              </div>
            </button>
          </div>
        </div>

        <button
          id="trigger-simplify-btn"
          onClick={handleSimplify}
          disabled={isLoading || !inputText.trim()}
          className="bg-indigo-600 hover:bg-indigo-500 text-white transition rounded-xl py-3 text-xs font-bold flex items-center justify-center gap-1.5 disabled:opacity-40 shadow-sm cursor-pointer"
        >
          {isLoading ? "Deconstructing content..." : "Simplify Material"}
        </button>

        {errorText && (
          <div className="p-2.5 rounded border border-red-200 bg-red-50 text-[10px] text-red-650 font-semibold">
            {errorText}
          </div>
        )}
      </div>

      {/* Right Result Board */}
      <div id="explainer-right" className="bg-white border border-zinc-200 rounded-xl p-5 flex flex-col h-full min-h-[400px] shadow-sm">
        <div className="border-b border-zinc-200 pb-3 mb-4 flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <Quote className="w-4 h-4 text-zinc-400" />
            <h4 className="font-semibold text-xs text-zinc-800">Deconstructed Workspace</h4>
          </div>
          {explanation && (
            <button
              id="copy-expo-btn"
              onClick={() => {
                navigator.clipboard.writeText(explanation);
                alert("Deconstructed text copied to clipboard!");
              }}
              className="text-[10px] text-indigo-600 hover:text-indigo-500 font-bold cursor-pointer transition"
            >
              Copy Text
            </button>
          )}
        </div>

        {isLoading ? (
          <div id="explainer-loading" className="flex-1 flex flex-col items-center justify-center text-zinc-400 text-center py-12 animate-pulse">
            <Sparkles className="w-8 h-8 text-indigo-600 mb-2 animate-spin-slow" />
            <h5 className="font-semibold text-zinc-800 text-xs">Defragmenting concepts...</h5>
            <p className="text-[11px] leading-relaxed max-w-xs mt-1 text-zinc-500">
              AI is scanning raw vocabulary structures to render simplified analogies and focus laws...
            </p>
          </div>
        ) : explanation ? (
          <div id="explainer-output" className="flex-1 overflow-y-auto max-h-[480px] bg-zinc-50 border border-zinc-200 rounded-xl p-4.5">
            <span className="text-[9px] font-bold tracking-wider text-indigo-600 block uppercase mb-2">
              {getModeTitle()}
            </span>
            <p className="text-zinc-800 text-xs font-normal leading-relaxed whitespace-pre-wrap">
              {explanation}
            </p>
          </div>
        ) : (
          <div id="explainer-placeholder" className="flex-1 flex flex-col items-center justify-center text-zinc-400 text-center border border-dashed border-zinc-200 rounded-xl p-6 bg-zinc-50/50">
            <FileText className="w-8 h-8 text-zinc-400 mb-2" />
            <h5 className="font-semibold text-zinc-700 text-xs">Explanations appear here</h5>
            <p className="text-[11px] leading-relaxed max-w-xs mt-1 text-zinc-500">
              Provide study literature on the left and trigger compilation to see clean structured breakdowns here.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
