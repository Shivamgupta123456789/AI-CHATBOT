import { useState, useId, FormEvent } from "react";
import { 
  GraduationCap, User, Mail, ShieldCheck, Check, Sparkles, 
  BookOpen, ArrowRight, Layers, HelpCircle, Laptop, Cpu, 
  Settings, HeartPulse, Building2, Server, UtilityPole, FlaskConical, CircleDot
} from "lucide-react";
import { StudentProfile } from "./StudentAuthPortal";

const PRESET_STUDENTS: StudentProfile[] = [
  {
    name: "Rohan Sharma",
    email: "rohan.cse@btech.edu",
    major: "B.Tech Computer Science & Engineering (CSE)",
    avatarSeed: "RS",
    color: "bg-indigo-650"
  },
  {
    name: "Priya Patel",
    email: "priya.ece@btech.edu",
    major: "B.Tech Electronics & Communication Engineering (ECE)",
    avatarSeed: "PP",
    color: "bg-emerald-600"
  },
  {
    name: "Vikram Singh",
    email: "vikram.me@btech.edu",
    major: "B.Tech Mechanical Engineering (ME)",
    avatarSeed: "VS",
    color: "bg-amber-600"
  },
  {
    name: "Ananya Iyer",
    email: "ananya.bt@btech.edu",
    major: "B.Tech Biotechnology Engineering (BT)",
    avatarSeed: "AI",
    color: "bg-purple-600"
  },
  {
    name: "Kabir Mehta",
    email: "kabir.ce@btech.edu",
    major: "B.Tech Civil Engineering (CE)",
    avatarSeed: "KM",
    color: "bg-rose-600"
  }
];

const BTECH_STREAMS = [
  {
    id: "cse",
    name: "Computer Science & Engineering (CSE)",
    icon: Laptop,
    color: "border-indigo-200 text-indigo-600 bg-indigo-50/40",
    courses: ["Data Structures", "Computer Organization", "Database Systems", "Operating Systems", "Web Technology", "Compiler Design"]
  },
  {
    id: "ece",
    name: "Electronics & Communication (ECE)",
    icon: Cpu,
    color: "border-emerald-200 text-emerald-600 bg-emerald-50/40",
    courses: ["Signals & Systems", "Analog Electronics", "Digital Signal Processing", "Microcontrollers", "VLSI Technology", "IoT systems"]
  },
  {
    id: "me",
    name: "Mechanical Engineering (ME)",
    icon: Settings,
    color: "border-amber-200 text-amber-600 bg-amber-50/40",
    courses: ["Thermodynamics", "Fluid Mechanics", "CAD/CAM & FEM", "Automobile Systems", "Robotics & Kinematics", "Material Science"]
  },
  {
    id: "bt",
    name: "Biotechnology Engineering (BT)",
    icon: HeartPulse,
    color: "border-purple-200 text-purple-600 bg-purple-50/40",
    courses: ["Cell Biology", "Genetic Engineering", "Bioinformatics", "Bioreactor Design", "Immunology", "Molecular Biology"]
  },
  {
    id: "ce",
    name: "Civil Engineering (CE)",
    icon: Building2,
    color: "border-rose-200 text-rose-600 bg-rose-50/40",
    courses: ["Structural Analysis", "Geotechnical Engineering", "Concrete Tech", "Surveying & Leveling", "Transportation Engg", "Hydraulic Structures"]
  },
  {
    id: "it",
    name: "Information Technology (IT)",
    icon: Server,
    color: "border-violet-200 text-violet-600 bg-violet-50/40",
    courses: ["Software Engineering", "Cloud Architecture", "Computer Networks", "Cyber Security", "Cryptography", "Mobile App Development"]
  },
  {
    id: "eee",
    name: "Electrical & Electronics (EEE)",
    icon: UtilityPole,
    color: "border-cyan-200 text-cyan-600 bg-cyan-50/40",
    courses: ["Electrical Machines", "Power Electronics", "Control Systems", "Electromagnetic Fields", "Renewable Energy", "Smart Grids"]
  },
  {
    id: "ch",
    name: "Chemical Engineering (CH)",
    icon: FlaskConical,
    color: "border-teal-200 text-teal-600 bg-teal-50/40",
    courses: ["Material Energy Balance", "Process Dynamics", "Chemical Reaction Engg", "Heat & Mass Transfer", "Polymer Technology", "Petroleum refining"]
  },
  {
    id: "aids",
    name: "Artificial Intelligence & Data Science",
    icon: CircleDot,
    color: "border-pink-200 text-pink-600 bg-pink-50/40",
    courses: ["Machine Learning", "Probability & Statistics", "Neural Networks", "Data Visualization", "Natural Language Processing", "Big Data Analytics"]
  }
];

interface StudentLoginPageProps {
  onLogin: (profile: StudentProfile) => void;
}

export default function StudentLoginPage({ onLogin }: StudentLoginPageProps) {
  const [customName, setCustomName] = useState("");
  const [customEmail, setCustomEmail] = useState("");
  const [customMajor, setCustomMajor] = useState("B.Tech Computer Science & Engineering (CSE)");
  
  const [activeTab, setActiveTab] = useState<"preset" | "custom">("preset");
  const [selectedStreamId, setSelectedStreamId] = useState<string>("cse");
  
  const [statusText, setStatusText] = useState("");
  const [isAuthenticating, setIsAuthenticating] = useState(false);

  const nameInputId = useId();
  const mailInputId = useId();
  const majorInputId = useId();

  const handleCustomLogin = (e: FormEvent) => {
    e.preventDefault();
    if (!customName.trim() || !customEmail.trim()) {
      setStatusText("Please fill out all fields.");
      return;
    }

    setIsAuthenticating(true);
    setStatusText("Verifying engineering credentials...");

    setTimeout(() => {
      setStatusText("Mapping stream curriculum & syllabus...");
      setTimeout(() => {
        setStatusText("Login successful! Unlocking workspace...");
        setTimeout(() => {
          const initialLetter = customName.trim().substring(0, 2).toUpperCase();
          onLogin({
            name: customName.trim(),
            email: customEmail.trim(),
            major: customMajor,
            avatarSeed: initialLetter.length > 1 ? initialLetter : initialLetter + "S",
            color: "bg-indigo-650"
          });
          setIsAuthenticating(false);
          setStatusText("");
        }, 500);
      }, 600);
    }, 800);
  };

  const handleSelectPreset = (student: StudentProfile) => {
    setIsAuthenticating(true);
    setStatusText(`Authenticating as ${student.name}...`);

    setTimeout(() => {
      setStatusText(`Loading ${student.major} resources...`);
      setTimeout(() => {
        setStatusText("Login successful! Welcome to the workspace.");
        setTimeout(() => {
          onLogin(student);
          setIsAuthenticating(false);
          setStatusText("");
        }, 500);
      }, 600);
    }, 800);
  };

  const activeStream = BTECH_STREAMS.find(s => s.id === selectedStreamId) || BTECH_STREAMS[0];

  return (
    <div id="student-login-page-root" className="min-h-screen flex flex-col justify-center items-center py-12 px-4 sm:px-6 lg:px-8 bg-[#f4f4f7] relative">
      <div className="absolute inset-0 pointer-events-none z-0 overflow-hidden">
        <img 
          src="https://images.unsplash.com/photo-1497633762265-9d179a990aa6?q=85&w=1920&auto=format&fit=crop" 
          alt="Library Study Room Background decoration"
          className="w-full h-full object-cover grayscale opacity-[0.05]"
          referrerPolicy="no-referrer"
        />
      </div>

      <div className="w-full max-w-5xl z-10 flex flex-col gap-8">
        
        {/* Workspace Brand and Greeting */}
        <div className="text-center flex flex-col items-center gap-3">
          <div className="w-14 h-14 bg-indigo-600 rounded-2xl flex items-center justify-center text-white shadow-xl animate-bounce">
            <GraduationCap className="w-8 h-8" />
          </div>
          <div>
            <h1 className="text-3xl font-extrabold text-zinc-900 tracking-tight">
              DeskMate Study Workspace
            </h1>
            <p className="text-zinc-600 text-sm max-w-md mx-auto mt-1 min-h-[20px]">
              Access premium micro-learning, interactive active-recall flashcards, and adaptive exam feedback.
            </p>
          </div>
        </div>

        {/* Central Card layout: Left displays Streams, Right displays login form */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          
          {/* Left panel: B.Tech Streams Exploration & curriculum preview */}
          <div className="lg:col-span-7 bg-white border border-zinc-250 rounded-2xl p-6.5 shadow-sm flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 mb-4 border-b border-zinc-150 pb-3">
                <BookOpen className="w-5 h-5 text-indigo-500" />
                <h2 className="font-extrabold text-zinc-900 text-sm uppercase tracking-wider">
                  Select & Discover B.Tech Course Streams
                </h2>
              </div>

              <p className="text-zinc-500 text-xs mb-4">
                Click a branch badge to inspect standard subjects dynamically integrated into your Study Companion:
              </p>

              {/* Grid of B.Tech Branches */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 mb-6">
                {BTECH_STREAMS.map((s) => {
                  const IconComponent = s.icon;
                  return (
                    <button
                      key={s.id}
                      onClick={() => setSelectedStreamId(s.id)}
                      className={`p-3.5 border rounded-xl flex items-center gap-2.5 text-left transition text-xs font-bold cursor-pointer ${
                        selectedStreamId === s.id
                          ? "ring-2 ring-indigo-500 border-indigo-500 bg-indigo-50 text-indigo-900"
                          : "border-zinc-200 bg-zinc-50 hover:bg-zinc-100 text-zinc-750"
                      }`}
                    >
                      <div className={`w-7 h-7 rounded-lg flex items-center justify-center border ${s.color}`}>
                        <IconComponent className="w-4 h-4" />
                      </div>
                      <span className="truncate leading-tight block">{s.name.replace("B.Tech ", "")}</span>
                    </button>
                  );
                })}
              </div>

              {/* Mini curriculum/course list */}
              <div className="bg-zinc-50 border border-zinc-150 rounded-xl p-4">
                <div className="flex items-baseline justify-between mb-2">
                  <span className="text-[10px] font-extrabold text-zinc-400 uppercase tracking-widest block">Stream Curriculum:</span>
                  <span className="text-[11px] font-extrabold text-indigo-600">{activeStream.name}</span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  {activeStream.courses.map((course, idx) => (
                    <div key={idx} className="flex items-center gap-2 text-xs text-zinc-700 bg-white border border-zinc-200/80 px-2.5 py-1.5 rounded-lg">
                      <div className="w-1.5 h-1.5 rounded-full bg-indigo-500" />
                      <span className="truncate">{course}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="mt-5 pt-3.5 border-t border-zinc-100 text-[11px] text-zinc-400 flex items-center gap-1.5 justify-center lg:justify-start">
              <ShieldCheck className="w-4 h-4 text-emerald-500" />
              <span>No credit card required. Stream-tailored mock questions will be built successfully.</span>
            </div>
          </div>

          {/* Right panel: Student Authentication Form */}
          <div className="lg:col-span-5 bg-white border border-zinc-250 rounded-2xl p-6.5 shadow-sm flex flex-col gap-5 justify-between relative overflow-hidden">
            
            {/* Authenticating Indicator backdrop banner */}
            {isAuthenticating && (
              <div className="absolute inset-0 bg-white/95 backdrop-blur-subtle flex flex-col justify-center items-center gap-4 z-30 p-6 text-center animate-fade-in">
                <div className="w-12 h-12 rounded-full border-4 border-indigo-100 border-t-indigo-600 animate-spin" />
                <div>
                  <h4 className="font-extrabold text-zinc-900 text-sm">Validating Student Identity</h4>
                  <p className="text-zinc-500 text-xs mt-1 font-mono tracking-tight">{statusText}</p>
                </div>
              </div>
            )}

            <div>
              {/* Login Sub-heading Tab control */}
              <div className="flex border-b border-zinc-200 mb-5">
                <button
                  onClick={() => setActiveTab("preset")}
                  className={`flex-1 text-center pb-2.5 text-xs font-bold leading-none tracking-tight transition cursor-pointer border-b-2 ${
                    activeTab === "preset"
                      ? "border-indigo-600 text-indigo-600"
                      : "border-transparent text-zinc-400 hover:text-zinc-600"
                  }`}
                >
                  Quick Preset Student Login
                </button>
                <button
                  onClick={() => setActiveTab("custom")}
                  className={`flex-1 text-center pb-2.5 text-xs font-bold leading-none tracking-tight transition cursor-pointer border-b-2 ${
                    activeTab === "custom"
                      ? "border-indigo-600 text-indigo-600"
                      : "border-transparent text-zinc-400 hover:text-zinc-600"
                  }`}
                >
                  Custom Student Login
                </button>
              </div>

              {activeTab === "preset" ? (
                /* Preset Quick Login Cards */
                <div className="flex flex-col gap-2.5">
                  <span className="text-[10px] font-extrabold text-zinc-450 uppercase tracking-wider block mb-1">
                    Choose an registered B.Tech Student Profile:
                  </span>
                  
                  {PRESET_STUDENTS.map((student) => (
                    <button
                      key={student.email}
                      type="button"
                      onClick={() => handleSelectPreset(student)}
                      className="w-full text-left p-3 border border-zinc-200 hover:border-indigo-400 hover:bg-zinc-50/50 rounded-xl transition flex items-center justify-between gap-3 group cursor-pointer"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <div className={`w-8 h-8 rounded-full ${student.color} text-white font-extrabold text-xs flex items-center justify-center flex-shrink-0 shadow-sm`}>
                          {student.avatarSeed}
                        </div>
                        <div className="min-w-0">
                          <h4 className="text-xs font-extrabold text-zinc-900 group-hover:text-indigo-600 transition leading-none">
                            {student.name}
                          </h4>
                          <span className="text-[10px] text-zinc-500 block truncate mt-1">
                            {student.major}
                          </span>
                        </div>
                      </div>
                      <div className="p-1 px-2.5 bg-zinc-100 group-hover:bg-indigo-50 text-[10px] group-hover:text-indigo-600 text-zinc-500 font-extrabold rounded-lg tracking-wider uppercase transition flex items-center gap-1 flex-shrink-0">
                        <span>Select</span>
                        <ArrowRight className="w-2.5 h-2.5 group-hover:translate-x-0.5 transition" />
                      </div>
                    </button>
                  ))}
                </div>
              ) : (
                /* Custom Student Login Form */
                <form onSubmit={handleCustomLogin} className="flex flex-col gap-4">
                  <div>
                    <label htmlFor={nameInputId} className="block text-[10px] font-extrabold text-zinc-500 uppercase tracking-wider">
                      Student Full Name:
                    </label>
                    <input
                      id={nameInputId}
                      type="text"
                      required
                      placeholder="e.g. Sameer Gupta"
                      value={customName}
                      onChange={e => setCustomName(e.target.value)}
                      className="w-full bg-zinc-50 border border-zinc-250 rounded-xl px-3 py-2.5 text-xs text-zinc-900 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 mt-1 placeholder-zinc-400"
                    />
                  </div>

                  <div>
                    <label htmlFor={mailInputId} className="block text-[10px] font-extrabold text-zinc-500 uppercase tracking-wider">
                      Student Academic Email Address:
                    </label>
                    <input
                      id={mailInputId}
                      type="email"
                      required
                      placeholder="e.g. sameer.g@btech.edu"
                      value={customEmail}
                      onChange={e => setCustomEmail(e.target.value)}
                      className="w-full bg-zinc-50 border border-zinc-250 rounded-xl px-3 py-2.5 text-xs text-zinc-900 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 mt-1 placeholder-zinc-400"
                    />
                  </div>

                  <div>
                    <label htmlFor={majorInputId} className="block text-[10px] font-extrabold text-zinc-500 uppercase tracking-wider">
                      B.Tech Engineering Stream / Course:
                    </label>
                    <select
                      id={majorInputId}
                      value={customMajor}
                      onChange={e => setCustomMajor(e.target.value)}
                      className="w-full bg-zinc-50 border border-zinc-200 rounded-xl px-3 py-2.5 text-xs text-zinc-900 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 mt-1 select-dropdown"
                    >
                      {BTECH_STREAMS.map(stream => (
                        <option key={stream.id} value={stream.name}>
                          {stream.name} (B.Tech)
                        </option>
                      ))}
                    </select>
                  </div>

                  {statusText && (
                    <div className="bg-rose-50 border border-rose-100 text-rose-600 text-xs p-2.5 rounded-lg font-medium">
                      {statusText}
                    </div>
                  )}

                  {/* Clean submission triggers Login successfully and enters App */}
                  <button
                    type="submit"
                    id="login-successful-submit-btn"
                    className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs py-3 px-4 rounded-xl shadow-lg tracking-wide transition flex items-center justify-center gap-2 cursor-pointer mt-2"
                  >
                    <span>⚡ LOGIN SUCCESSFUL & ENTER WORKSPACE</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </form>
              )}
            </div>

            <div className="border-t border-zinc-100 pt-3 text-center">
              <span className="text-[10px] text-zinc-400">
                You are entering the standard academic client workspace.
              </span>
            </div>
          </div>

        </div>

        {/* Dynamic bottom detail banner of course catalog */}
        <div className="bg-white border border-zinc-200 rounded-xl p-5 shadow-sm text-center">
          <span className="text-[10px] font-extrabold text-zinc-400 tracking-wider uppercase inline-block mb-2">Workspace Curriculum Integration Matrix</span>
          <div className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-[11px] text-zinc-500 font-medium">
            <span className="flex items-center gap-1"><Check className="w-3.5 h-3.5 text-emerald-500" /> Syllabus Mapping</span>
            <span className="hidden sm:inline">|</span>
            <span className="flex items-center gap-1"><Check className="w-3.5 h-3.5 text-emerald-500" /> Smart Explanations</span>
            <span className="hidden sm:inline">|</span>
            <span className="flex items-center gap-1"><Check className="w-3.5 h-3.5 text-emerald-500" /> Topic Level Active Recalls</span>
            <span className="hidden sm:inline">|</span>
            <span className="flex items-center gap-1"><Check className="w-3.5 h-3.5 text-emerald-500" /> B.Tech Semester Planning</span>
          </div>
        </div>

      </div>
    </div>
  );
}
